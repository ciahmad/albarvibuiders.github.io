<?php
@session_start(); 
@ob_start();
if(empty($_SESSION['login_id'])){
$_SESSION['u_err']="Session Expired, Please login again.";
header("location:index.php");
}
?>