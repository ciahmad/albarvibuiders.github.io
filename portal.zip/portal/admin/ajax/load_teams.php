<?php
include("../chksession.php");
include("../Common.php");
?>
	<select name="id_team" class="form-control">';
    <?php
    $teams=mysqli_query($con,"select * from teams where id_company=".$_GET['idc']);
	while($c=mysqli_fetch_array($teams)){
		?>
		<option value="<?php echo $c['id'];?>"><?php echo $c['team_name'];?></option>
	<?php
	}
    ?>
    </select>