<?php

include("chksession.php");

include("Common.php");

	$sql="update qoutations set status='Approved', update_dt=now(),update_by='".mysqli_real_escape_string($con,$_SESSION['login_id'])."' where id='".mysqli_real_escape_string($con,$_GET['id'])."'";
			
			$result= mysqli_query($con,$sql);
			
			$q="INSERT INTO invoices (`project_id`, `project_title`, `project_company`, `project_customer`, `project_location`, `total_qty`, `total_amount`, `total_tax`, `total_discount`, `total_paid`, `gross_amount`, `create_by`)
SELECT `project_id`, `project_title`, `project_company`, `project_customer`, `project_location`, `total_qty`, `total_amount`, `total_tax`, `total_discount`, `total_paid`, `gross_amount`, `create_by` FROM `qoutations` WHERE `id` ='".mysqli_real_escape_string($con,$_GET['id'])."'";
			$invoice= mysqli_query($con,$q);



	$_SESSION['msg']="invoice has been created.";

	mysqli_close($con);	

header("location:employees.php");

?>