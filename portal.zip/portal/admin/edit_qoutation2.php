<?php
include("chksession.php");

include("Common.php");
if($_POST["products_ids"]){
	
			

			$sql="update qoutations set project_id='".mysqli_real_escape_string($con,$_GET['project_id'])."',project_title='".mysqli_real_escape_string($con,$_POST['title'])."',project_company='".mysqli_real_escape_string($con,$_POST['company'])."',project_customer='".mysqli_real_escape_string($con,$_POST['customer_name'])."',project_location='".mysqli_real_escape_string($con,$_POST['location'])."',total_qty=".sizeof($_POST["products_ids"]).",total_amount='".mysqli_real_escape_string($con,$_POST['total_price'])."',total_tax='".mysqli_real_escape_string($con,$_POST['total_tax'])."',total_discount='".mysqli_real_escape_string($con,$_POST['total_discount'])."',total_paid='".mysqli_real_escape_string($con,$_POST['total_paid'])."',gross_amount='".mysqli_real_escape_string($con,$_POST['gross_amount'])."', create_dt=now(),create_by='".mysqli_real_escape_string($con,$_SESSION['login_id'])."' where id='".mysqli_real_escape_string($con,$_GET['qoutation_id'])."'";
			
			$result= mysqli_query($con,$sql);
			
			mysqli_query($con,"delete from qoutation_items where qoutation_id='".mysqli_real_escape_string($con,$_GET['qoutation_id'])."'");
			
			
			for($i=0; $i < sizeof($_POST["products_ids"]); $i++){
				$q="insert into qoutation_items set qoutation_id=".mysqli_real_escape_string($con,$_GET['qoutation_id']).",product_id='".mysqli_real_escape_string($con,$_POST['products_ids'][$i])."',product_name='".mysqli_real_escape_string($con,$_POST['products_name'][$i])."',product_qty='".mysqli_real_escape_string($con,$_POST['products_qty'][$i])."',product_rate='".mysqli_real_escape_string($con,$_POST['products_rate'][$i])."',product_price='".mysqli_real_escape_string($con,$_POST['products_total'][$i])."'"; 
			$result2= mysqli_query($con,$q);
			//echo $q;
			
			}
			//exit;
			

			$_SESSION['msg']="Qoutation has been Updated.";
			header('location:project_qoutations.php?id='.$_GET['project_id']);

}else{
	$_SESSION['err']="At least 01 product required.";
	header('location:edit_qoutation.php?id='.$_GET['project_id'].'&qoutation_id='.$_GET['qoutation_id']);
}
			mysqli_close($con);
		

	



?>