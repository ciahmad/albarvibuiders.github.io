<?php
//$con = mysqli_connect("localhost","root","","cantt_entry");
include("chksession.php");

include("Common.php");
//$tt=date("Ymdhis");
			
			
			$result= mysqli_query($con,"insert into vendors set vindor_id='".mysqli_real_escape_string($con,$_POST['vindor_id'])."',name='".mysqli_real_escape_string($con,$_POST['name'])."',fname='".mysqli_real_escape_string($con,$_POST['fname'])."',cnic='".mysqli_real_escape_string($con,$_POST['cnic'])."',phone='".mysqli_real_escape_string($con,$_POST['phone'])."',dob='".mysqli_real_escape_string($con,$_POST['dob'])."',designation='".mysqli_real_escape_string($con,$_POST['designation'])."',address='".mysqli_real_escape_string($con,$_POST['address'])."',email='".mysqli_real_escape_string($con,$_POST['email'])."',company='".mysqli_real_escape_string($con,$_POST['company'])."'");
			
			

			$_SESSION['msg']="Vendor  has been created.";


			mysqli_close($con);		

	header('location:vendors.php');



?>