<?php 

include("chksession.php");
include("Common.php");
include('header.php');
 ?>
        <!-- BEGIN CONTAINER -->

        <div class="page-container">

            <!-- BEGIN SIDEBAR -->

            <?php include('left_sidebar.php'); ?>

            <!-- END SIDEBAR -->

            <!-- BEGIN CONTENT -->

            <div class="page-content-wrapper">

                <!-- BEGIN CONTENT BODY -->

                <div class="page-content">

                    <!-- BEGIN PAGE HEAD-->

                    <div class="page-head">

                        <!-- BEGIN PAGE TITLE -->

                        <div class="page-title">

                            <h1>Expense Management

                                <small>Add Expense</small>

                            </h1>

                        </div>

                        <!-- END PAGE TITLE -->

                        <!-- BEGIN PAGE TOOLBAR -->

                        <!-- END PAGE TOOLBAR -->

                    </div>

                    <!-- END PAGE HEAD-->

                    <!-- BEGIN PAGE BREADCRUMB -->

                    <ul class="page-breadcrumb breadcrumb">
                        <li>
                            <a href="expenses_khi.php">Expense</a></li>
                        <li>
                            <span class="active">Add New Expense</span>
                        </li>
                    </ul>

                    <!-- END PAGE BREADCRUMB -->

                    <!-- BEGIN PAGE BASE CONTENT -->                    
                    <div class="row">

                    	<div class="col-sm-12">

                        	<div class="portlet box blue ">

                                <div class="portlet-title">

                                    <div class="caption">

                                        <i class="fa fa-gift"></i>Create New Employee</div>

                                   
                                </div>

                                <div class="portlet-body form">

                                    <!--<form role="form">
                                        <div class="form-body">

                                            <div class="form-group has-success">

                                                <label class="control-label">Input with success</label>

                                                <input type="text" class="form-control" id="inputSuccess"> </div>

                                            <div class="form-group has-warning">

                                                <label class="control-label">Input with warning</label>

                                                <input type="text" class="form-control" id="inputWarning"> </div>

                                            <div class="form-group has-error">

                                                <label class="control-label">Input with error</label>

                                                <input type="text" class="form-control" id="inputError"> </div>

                                        </div>

                                        <div class="form-actions">

                                            <button type="button" class="btn default">Cancel</button>

                                            <button type="submit" class="btn red">Submit</button>

                                        </div>

                                    </form>-->

                                    <form class="form-horizontal" method="post" role="form" action="add_expense2_karachi.php" enctype="multipart/form-data">

                                        <div class="form-body">
										
											<div class="row">
                                            <div class="col-sm-6">
                                                <div class="form-group">

                                                		<label class="col-sm-4 control-label">Title:</label>
                                                		<div class="col-sm-8">
														<input class="form-control" name="title" value="" type="text">                                              			
                                                        </div>
                                            		</div>
                                                	
											
                                                    <div class="form-group">
        
                                                        <label class="col-sm-4 control-label">Description:</label>
                                                        <div class="col-sm-8">
        
                                                      <input class="form-control" name="description" value="" type="text"> </div>
        
                                                    </div>
							
										
										</div>
										
                                                <div class="col-sm-6">
            
                                                <div class="form-group">

                                                    <label class="col-sm-4 control-label">Amount :</label>
                                                    <div class="col-sm-8">

                                                    <input class="form-control" name="amount" value="" type="number"> 
                                                    </div>
                                                    </div>
																					
											 </div>										                                            
										</div>
											
                                        <div class="form-actions right1">
                                            <button type="button" class="btn default" onclick="window.location='employees.php'">Cancel</button>
                                            <button type="submit" class="btn green">Save</button>
                                        </div>                                        
                                        </div>
                                    </form>								
                                </div>
                            </div>
                        </div>

                    </div>
                    
                    <!-- END PAGE BASE CONTENT -->

                </div>

                <!-- END CONTENT BODY -->

            </div>

            <!-- END CONTENT -->

            <!-- BEGIN QUICK SIDEBAR -->

            

            

            <!-- END QUICK SIDEBAR -->

        </div>

        <!-- END CONTAINER -->

        <!-- BEGIN FOOTER -->

        <?php include('footer.php'); ?>

        

        <!-- END FOOTER -->

        <!-- BEGIN QUICK NAV -->

        <?php //include('quick_nav.php'); ?>

        

        

        <!-- END QUICK NAV -->

        <!--[if lt IE 9]>

<script src="../assets/global/plugins/respond.min.js"></script>

<script src="../assets/global/plugins/excanvas.min.js"></script> 

<script src="../assets/global/plugins/ie8.fix.min.js"></script> 

<![endif]-->

        <!-- BEGIN CORE PLUGINS -->

        <?php include('core_plugins.php'); ?>

        <script src="../assets/global/plugins/bootstrap-fileinput/bootstrap-fileinput.js" type="text/javascript"></script>

        <script src="../assets/global/plugins/bootstrap-datetimepicker/js/bootstrap-datetimepicker.min.js" type="text/javascript"></script>

        <script src="../assets/pages/scripts/components-date-time-pickers.min.js" type="text/javascript"></script>

        <script type="text/javascript">

    		$(".date-picker").datetimepicker({format: 'yyyy-mm-dd hh:ii'});

		</script>
        <script type="text/javascript" src="js/webcam.min.js"></script>
        <script type="text/javascript" src="js/custom.js"></script>

    </body>



</html>