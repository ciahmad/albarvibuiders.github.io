<?php

//$con = mysqli_connect("localhost","root","");
//$con = mysqli_connect("localhost","rganixla_admin","AAwerk6762");
//$con = mysqli_connect("localhost","u251100480_root","Xbo0vmX3LsTuMW@#");
$con = mysqli_connect("localhost","root","");
//mysqli_select_db($con,"u251100480_albarviadmin")or die("db not connected");
mysqli_select_db($con,"albarvi_portal")or die("db not connected");



define("appname","EMPR");
//include('paginate.php');
$per_page = 15; 
$page=explode('/',$_SERVER['REQUEST_URI']);
$p=explode('.php',$page[1]);
$p=$p[0];
$active='class="active"';


function mysqli_result($res,$row=0,$col=0){ 
    $numrows = mysqli_num_rows($res); 
    if ($numrows && $row <= ($numrows-1) && $row >=0){
        mysqli_data_seek($res,$row);
        $resrow = (is_numeric($col)) ? mysqli_fetch_row($res) : mysqli_fetch_assoc($res);
        if (isset($resrow[$col])){
            return $resrow[$col];
        }
    }
    return false;
}
?>
