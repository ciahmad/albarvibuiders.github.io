<?php  include("../Common.php");

$main_array=array();

$sql="SELECT id,p_code,name,sale_price from products WHERE status='Active' ORDER BY name ASC ";
//$notifications=mysqli_query($con,"select * from app_notifications");
$products=mysqli_query($con,$sql);
if(mysqli_num_rows($products)>0){
	$product_array=array();
	while($row=mysqli_fetch_array($products)){
		
		$sub_array=array("id"=>$row['id'],"s_no"=>$row['p_code'],"name"=>$row['name'],"rate"=>$row['sale_price']);
			array_push($product_array,$sub_array);
	}
	$main_array=array("Success"=>"1", "products"=>$product_array);
}else{
	$main_array=array("Success"=>"0");

}
echo json_encode($main_array);
 ?>