<?php
//$con = mysqli_connect("localhost","root","","cantt_entry");
include("chksession.php");

include("Common.php");
//$tt=date("Ymdhis");
			
			
			$result= mysqli_query($con,"update customers set company='".mysqli_real_escape_string($con,$_POST['company'])."',phone='".mysqli_real_escape_string($con,$_POST['phone'])."',email='".mysqli_real_escape_string($con,$_POST['email'])."',address='".mysqli_real_escape_string($con,$_POST['address'])."',cperson_name='".mysqli_real_escape_string($con,$_POST['cperson_name'])."',cperson_phone='".mysqli_real_escape_string($con,$_POST['cperson_phone'])."',cperson_email='".mysqli_real_escape_string($con,$_POST['cperson_email'])."',reg_date='".mysqli_real_escape_string($con,$_POST['reg_date'])."' where id=".$_GET['id']);
			
			

			$_SESSION['msg']="Customer has been Updated.";


			mysqli_close($con);		

	header('location:customers.php');



?>