<?php 

include("chksession.php");

include("Common.php");

include('header.php'); ?>




	

        <!-- BEGIN CONTAINER -->

        <div class="page-container">

            <!-- BEGIN SIDEBAR -->

            <?php include('left_sidebar.php'); ?>

            <!-- END SIDEBAR -->

            <!-- BEGIN CONTENT -->

            <div class="page-content-wrapper">

                <!-- BEGIN CONTENT BODY -->

                <div class="page-content">

                    <!-- BEGIN PAGE HEAD-->

                    <div class="page-head">

                        <!-- BEGIN PAGE TITLE -->

                        <div class="page-title">

                            <h1>Welcome

                                <small>statistics</small>

                            </h1>

                        </div>

                        <!-- END PAGE TITLE -->

                        <!-- BEGIN PAGE TOOLBAR -->

                        

                        <!-- END PAGE TOOLBAR -->

                    </div>

                    <!-- END PAGE HEAD-->

                    <!-- BEGIN PAGE BREADCRUMB -->

                    <ul class="page-breadcrumb breadcrumb">

                        <!--<li>

                            <a href="welcome.php">Home</a>

                            <i class="fa fa-circle"></i>

                        </li>-->

                        <li>

                            <span class="active">Dashboard</span>

                        </li>

                    </ul>

                    <!-- END PAGE BREADCRUMB -->

                    <!-- BEGIN PAGE BASE CONTENT -->

                    <div class="row widget-row">
					
					

                        <?php if($_SESSION['login_role']=="Admin"){?>

                        
						
						<div class="col-md-2">

                            <!-- BEGIN WIDGET THUMB -->

							<?php 

							  $employees=0; 

							  $sql="SELECT * FROM employees";

							  if ($result=mysqli_query($con,$sql))

								{

								  $rowcount=mysqli_num_rows($result);

									//echo $rowcount;

									$employees=$rowcount;

								  mysqli_free_result($result);

							  }

							  ?>

                            <div class="widget-thumb widget-bg-color-white text-uppercase margin-bottom-20 bordered">

                                <h4 class="widget-thumb-heading">Total Site Office</h4>

                                <div class="widget-thumb-wrap">

                                    <i class="widget-thumb-icon bg-blue icon-layers"></i>

                                    <div class="widget-thumb-body">

                                        <span class="widget-thumb-subtitle"></span>

                                        <span class="widget-thumb-body-stat" data-counter="counterup" data-value="<?php echo $employees; ?>">0</span>

                                    </div>

                                </div>

                            </div>

                            <!-- END WIDGET THUMB -->

                        </div>
						
						<div class="col-md-2">

                            <!-- BEGIN WIDGET THUMB -->

							<?php 

							  $product_categories=0; 

							  $sql="SELECT * FROM product_categories";

							  if ($result=mysqli_query($con,$sql))

								{

								  $rowcount=mysqli_num_rows($result);

									//echo $rowcount;

									$product_categories=$rowcount;

								  mysqli_free_result($result);

							  }

							  ?>

                            <div class="widget-thumb widget-bg-color-white text-uppercase margin-bottom-20 bordered">

                                <h4 class="widget-thumb-heading">Total Income</h4>

                                <div class="widget-thumb-wrap">

                                    <i class="widget-thumb-icon bg-green icon-layers"></i>

                                    <div class="widget-thumb-body">

                                        <span class="widget-thumb-subtitle"></span>

                                        <span class="widget-thumb-body-stat" data-counter="counterup" data-value="<?php echo $product_categories; ?>">0</span>

                                    </div>

                                </div>

                            </div>

                            <!-- END WIDGET THUMB -->

                        </div>
                        
                        <div class="col-md-2">

                            <!-- BEGIN WIDGET THUMB -->

							<?php 

							  $customers=0; 

							  $sql="SELECT * FROM customers";

							  if ($result=mysqli_query($con,$sql))

								{

								  $rowcount=mysqli_num_rows($result);

									//echo $rowcount;

									$customers=$rowcount;

								  mysqli_free_result($result);

							  }

							  ?>

                            <div class="widget-thumb widget-bg-color-white text-uppercase margin-bottom-20 bordered">

                                <h4 class="widget-thumb-heading">Total Expense</h4>

                                <div class="widget-thumb-wrap">

                                    <i class="widget-thumb-icon bg-yellow icon-layers"></i>

                                    <div class="widget-thumb-body">

                                        <span class="widget-thumb-subtitle"></span>

                                        <span class="widget-thumb-body-stat" data-counter="counterup" data-value="<?php echo $customers; ?>">0</span>

                                    </div>

                                </div>

                            </div>

                            <!-- END WIDGET THUMB -->

                        </div>
						
						<div class="col-md-2">

                            <!-- BEGIN WIDGET THUMB -->

							<?php 

							  $vendors=0; 

							  $sql="SELECT * FROM vendors";

							  if ($result=mysqli_query($con,$sql))

								{

								  $rowcount=mysqli_num_rows($result);

									//echo $rowcount;

									$vendors=$rowcount;

								  mysqli_free_result($result);

							  }

							  ?>

                            <div class="widget-thumb widget-bg-color-white text-uppercase margin-bottom-20 bordered">

                                <h4 class="widget-thumb-heading">Total Vendors</h4>

                                <div class="widget-thumb-wrap">

                                    <i class="widget-thumb-icon bg-red icon-layers"></i>

                                    <div class="widget-thumb-body">

                                        <span class="widget-thumb-subtitle"></span>

                                        <span class="widget-thumb-body-stat" data-counter="counterup" data-value="<?php echo $vendors; ?>">0</span>

                                    </div>

                                </div>

                            </div>

                            <!-- END WIDGET THUMB -->

                        </div>
                        
						<div class="col-md-2">

                            <!-- BEGIN WIDGET THUMB -->

							<?php  

							  $sql="SELECT * FROM users";

							  $users=0;

							  if ($result=mysqli_query($con,$sql))

								{

								  // Return the number of rows in result set

								  $rowcount=mysqli_num_rows($result);

								// echo $rowcount;

								 $users=$rowcount;

								  // Free result set

								  mysqli_free_result($result);

							  }

							  ?> 

                            <div class="widget-thumb widget-bg-color-white text-uppercase margin-bottom-20 bordered">

                                <h4 class="widget-thumb-heading">Total Users</h4>

                                <div class="widget-thumb-wrap">

                                    <i class="widget-thumb-icon bg-dark icon-user-female"></i>

                                    <div class="widget-thumb-body">

                                        <span class="widget-thumb-subtitle"></span>

                                        <span class="widget-thumb-body-stat" data-counter="counterup" data-value="<?php echo $users; ?>">0</span>

                                    </div>

                                </div>

                            </div>
                            <?php } ?>

                            <!-- END WIDGET THUMB -->

                        </div>

                    </div>



                   

                    

                    

                    

                    

                    

                    

                    <!-- END PAGE BASE CONTENT -->

                </div>

                <!-- END CONTENT BODY -->

            </div>

            <!-- END CONTENT -->

            <!-- BEGIN QUICK SIDEBAR -->

            

            

            <!-- END QUICK SIDEBAR -->

        </div>

        <!-- END CONTAINER -->

        <!-- BEGIN FOOTER -->

        <?php include('footer.php'); ?>

        

        <!-- END FOOTER -->

        <!-- BEGIN QUICK NAV -->

        <?php //include('quick_nav.php'); ?>

        

        

        <!-- END QUICK NAV -->

        <!--[if lt IE 9]>

<script src="../assets/global/plugins/respond.min.js"></script>

<script src="../assets/global/plugins/excanvas.min.js"></script> 

<script src="../assets/global/plugins/ie8.fix.min.js"></script> 

<![endif]-->

        <!-- BEGIN CORE PLUGINS -->

        <?php include('core_plugins.php'); ?>

        

        <!-- END THEME LAYOUT SCRIPTS -->

        <script>

            $(document).ready(function()

            {

                $('#clickmewow').click(function()

                {

                    $('#radio1003').attr('checked', 'checked');

                });

            })

        </script>

    </body>



</html>