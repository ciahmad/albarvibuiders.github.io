<?php 

include("chksession.php");

include("Common.php");

include('header.php');

$vindors=mysqli_query($con,"select * from vendors where id='".mysqli_real_escape_string($con,$_GET['id'])."'");

$e=mysqli_fetch_array($vindors);

 ?>

        <!-- BEGIN CONTAINER -->

        <div class="page-container">

            <!-- BEGIN SIDEBAR -->

            <?php include('left_sidebar.php'); ?>

            <!-- END SIDEBAR -->

            <!-- BEGIN CONTENT -->

            <div class="page-content-wrapper">

                <!-- BEGIN CONTENT BODY -->

                <div class="page-content">

                    <!-- BEGIN PAGE HEAD-->

                    <div class="page-head">

                        <!-- BEGIN PAGE TITLE -->

                        <div class="page-title">

                            <h1>Vendors Management

                                <small>Add Vendor</small>

                            </h1>

                        </div>

                        <!-- END PAGE TITLE -->

                        <!-- BEGIN PAGE TOOLBAR -->

                        

                        <!-- END PAGE TOOLBAR -->

                    </div>

                    <!-- END PAGE HEAD-->

                    <!-- BEGIN PAGE BREADCRUMB -->

                    <ul class="page-breadcrumb breadcrumb">

                        <li>

                            <a href="vendors.php">Vendors</a></li>

                        <li>

                            <span class="active">Add New Vendor</span>

                        </li>

                    </ul>

                    <!-- END PAGE BREADCRUMB -->

                    <!-- BEGIN PAGE BASE CONTENT -->

                    

                    <div class="row">

                    	<div class="col-sm-12">

                        	<div class="portlet box blue ">

                                <div class="portlet-title">

                                    <div class="caption">

                                        <i class="fa fa-gift"></i>Create New Vendor</div>

                                   
                                </div>

                                <div class="portlet-body form">

                                    <!--<form role="form">

                                        <div class="form-body">

                                            <div class="form-group has-success">

                                                <label class="control-label">Input with success</label>

                                                <input type="text" class="form-control" id="inputSuccess"> </div>

                                            <div class="form-group has-warning">

                                                <label class="control-label">Input with warning</label>

                                                <input type="text" class="form-control" id="inputWarning"> </div>

                                            <div class="form-group has-error">

                                                <label class="control-label">Input with error</label>

                                                <input type="text" class="form-control" id="inputError"> </div>

                                        </div>

                                        <div class="form-actions">

                                            <button type="button" class="btn default">Cancel</button>

                                            <button type="submit" class="btn red">Submit</button>

                                        </div>

                                    </form>-->

                                    <form class="form-horizontal" method="post" role="form" action="edit_vendor2.php?id=<?php echo $e['id']?>" enctype="multipart/form-data">

                                        <div class="form-body">
										
											<div class="row">
                                            	<div class="col-sm-6">
                                                <div class="form-group">

                                                		<label class="col-sm-4 control-label">Vindor ID:</label>
                                                		<div class="col-sm-8">
														<input class="form-control" name="vindor_id" value="<?php echo $e['vindor_id']?>" type="text">
                                              			
                                                        </div>
                                            		</div>
                                                	<div class="form-group">

                                                		<label class="col-sm-4 control-label"> Name :</label>
                                                		<div class="col-sm-8">

                                              			<input class="form-control" name="name" value="<?php echo $e['name']?>" type="text"> 
                                                        </div>
                                            		</div>
											
                                                    <div class="form-group">
        
                                                        <label class="col-sm-4 control-label">Father Name:</label>
                                                        <div class="col-sm-8">
        
                                                      <input class="form-control" name="fname" value="<?php echo $e['fname']?>" type="text"> </div>
        
                                                    </div>
											
											
                                                    <div class="form-group">
        
                                                        <label class="col-sm-4 control-label"> CNIC:</label>
                                                        <div class="col-sm-8">
        
                                                      <input class="form-control" name="cnic" value="<?php echo $e['cnic']?>" type="text"> </div>
        
                                                    </div>

										

                                                    <div class="form-group">
        
                                                        <label class="col-sm-4 control-label"> Phone:</label>
        
                                                        <div class="col-sm-8">
        
                                                            <input name="phone" class="form-control" value="<?php echo $e['phone']?>" type="text"> 
                                                            
                                                         </div>
        
                                                    </div>

                                      
                                                    <div class="form-group">
        
                                                        <label class="col-sm-4 control-label"> D-O-B:</label>
        
                                                        <div class="col-sm-8">
        
                                                            <input name="dob" class="form-control" value="<?php echo $e['dob']?>" type="date"> 
                                                       	</div>
        
                                                    </div>

                                                    <div class="form-group">
    
                                                        <label class="col-sm-4 control-label"> Designation:</label>
        
                                                        <div class="col-sm-8">
        
                                                            <input name="designation" class="form-control" value="<?php echo $e['designation']?>" type="text"> 
                                                       	</div>
        
                                                    </div>
                                            
                                            		<div class="form-group">

                                                		<label class="col-sm-4 control-label">Address:</label>

                                                        <div class="col-sm-8">
        
                                                            <input name="address" class="form-control" value="<?php echo $e['address']?>" type="text"> 
                                                       	</div>
                                                   
                                                    </div>
											
											<div class="form-group">

                                                <label class="col-sm-4 control-label">E-Mail:</label>

                                                <div class="col-sm-8">

                                                    <input name="email" class="form-control" value="<?php echo $e['email']?>" type="text"> </div>
                                           
                                            </div>
                                            
                                            <div class="form-group">

                                                <label class="col-sm-4 control-label">Company Name:</label>

                                                <div class="col-sm-8">

                                                    <input name="company" class="form-control" value="<?php echo $e['company']?>" type="text"> </div>
                                           
                                            </div>
                                            
                                            
										</div>
										
                                                
										</div>
										 
											
											
											
                                        <div class="form-actions right1">

                                            <button type="button" class="btn default" onclick="window.location='vendors.php'">Cancel</button>

                                            <button type="submit" class="btn green">Save</button>

                                        </div>
                                        
                                        </div>

                                    </form>

									

                                </div>

                            </div>

                        

                        </div>

                    </div>

                    

                    

                    

                    

                    

                    

                    <!-- END PAGE BASE CONTENT -->

                </div>

                <!-- END CONTENT BODY -->

            </div>

            <!-- END CONTENT -->

            <!-- BEGIN QUICK SIDEBAR -->

            

            

            <!-- END QUICK SIDEBAR -->

        </div>

        <!-- END CONTAINER -->

        <!-- BEGIN FOOTER -->

        <?php include('footer.php'); ?>

        

        <!-- END FOOTER -->

        <!-- BEGIN QUICK NAV -->

        <?php //include('quick_nav.php'); ?>

        

        

        <!-- END QUICK NAV -->

        <!--[if lt IE 9]>

<script src="../assets/global/plugins/respond.min.js"></script>

<script src="../assets/global/plugins/excanvas.min.js"></script> 

<script src="../assets/global/plugins/ie8.fix.min.js"></script> 

<![endif]-->

        <!-- BEGIN CORE PLUGINS -->

        <?php include('core_plugins.php'); ?>

        <script src="../assets/global/plugins/bootstrap-fileinput/bootstrap-fileinput.js" type="text/javascript"></script>

        <script src="../assets/global/plugins/bootstrap-datetimepicker/js/bootstrap-datetimepicker.min.js" type="text/javascript"></script>

        <script src="../assets/pages/scripts/components-date-time-pickers.min.js" type="text/javascript"></script>

        <script type="text/javascript">

    		$(".date-picker").datetimepicker({format: 'yyyy-mm-dd hh:ii'});

		</script>
        <script type="text/javascript" src="js/webcam.min.js"></script>
        <script type="text/javascript" src="js/custom.js"></script>

    </body>



</html>