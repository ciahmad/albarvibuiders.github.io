<?php 

include("chksession.php");

include("Common.php");

include('header.php');

$product=mysqli_query($con,"select * from products where id='".mysqli_real_escape_string($con,$_GET['id'])."'");

$c=mysqli_fetch_array($product);

 ?>

        <!-- BEGIN CONTAINER -->

        <div class="page-container">

            <!-- BEGIN SIDEBAR -->

            <?php include('left_sidebar.php'); ?>

            <!-- END SIDEBAR -->

            <!-- BEGIN CONTENT -->

            <div class="page-content-wrapper">

                <!-- BEGIN CONTENT BODY -->

                <div class="page-content">

                    <!-- BEGIN PAGE HEAD-->

                    <div class="page-head">

                        <!-- BEGIN PAGE TITLE -->

                        <div class="page-title">

                            <h1>Product Management

                                <small>Add Product</small>

                            </h1>

                        </div>

                        <!-- END PAGE TITLE -->

                        <!-- BEGIN PAGE TOOLBAR -->

                        

                        <!-- END PAGE TOOLBAR -->

                    </div>

                    <!-- END PAGE HEAD-->

                    <!-- BEGIN PAGE BREADCRUMB -->

                    <ul class="page-breadcrumb breadcrumb">

                        <li>

                            <a href="products.php">Products</a></li>

                        <li>

                            <span class="active">Add New Product</span>

                        </li>

                    </ul>

                    <!-- END PAGE BREADCRUMB -->

                    <!-- BEGIN PAGE BASE CONTENT -->

                    

                    <div class="row">

                    	<div class="col-sm-12">

                        	<div class="portlet box blue ">

                                <div class="portlet-title">

                                    <div class="caption">

                                        <i class="fa fa-gift"></i>Create New Product</div>

                                   
                                </div>

                                <div class="portlet-body form">

                                    <!--<form role="form">

                                        <div class="form-body">

                                            <div class="form-group has-success">

                                                <label class="control-label">Input with success</label>

                                                <input type="text" class="form-control" id="inputSuccess"> </div>

                                            <div class="form-group has-warning">

                                                <label class="control-label">Input with warning</label>

                                                <input type="text" class="form-control" id="inputWarning"> </div>

                                            <div class="form-group has-error">

                                                <label class="control-label">Input with error</label>

                                                <input type="text" class="form-control" id="inputError"> </div>

                                        </div>

                                        <div class="form-actions">

                                            <button type="button" class="btn default">Cancel</button>

                                            <button type="submit" class="btn red">Submit</button>

                                        </div>

                                    </form>-->

                                    <form class="form-horizontal" method="post" role="form" action="edit_product2.php?id=<?php echo $c['id']?>" enctype="multipart/form-data">

                                        <div class="form-body">
										
											<div class="row">
                                            	<div class="col-sm-6">
                                                <div class="form-group">

                                                		<label class="col-sm-4 control-label">Product Code :</label>
                                                		<div class="col-sm-8">
														<input class="form-control" name="p_code" value="<?php echo $c['p_code']?>" type="text">
                                              			
                                                        </div>
                                            		</div>
                                                	<div class="form-group">

                                                		<label class="col-sm-4 control-label"> Name :</label>
                                                		<div class="col-sm-8">

                                              			<input class="form-control" name="name" value="<?php echo $c['name']?>" type="text"> 
                                                        </div>
                                            		</div>
											
                                                    <div class="form-group">
        
                                                        <label class="col-sm-4 control-label"> Detail:</label>
                                                        <div class="col-sm-8">
        
                                                      <input class="form-control" name="detail" value="<?php echo $c['detail']?>" type="text"> </div>
        
                                                    </div>
											
											
                                                    <div class="form-group">
        
                                                        <label class="col-sm-4 control-label">ID Category:</label>
                                                        <div class="col-sm-8">
														<select name="id_category"  class="form-control" >
                                                                <option value="<?php echo $c['id_category']?>"><?php echo $c['id_category']?></option>
    <?php
                                                                $category=mysqli_query($con,"select * from product_categories ORDER BY name ASC");
                                                                while($p=mysqli_fetch_array($category)){
                                                                    ?>
                                                                    <option value="<?php echo $p['name']?>"><?php echo $p['name']?></option>
                                                                  <?php 
                                                                }
                                                                ?>
															</select>
														
														
        
                                                       </div>
        
                                                    </div>

										

                                                    <div class="form-group">
        
                                                        <label class="col-sm-4 control-label"> Tax Type :</label>
        
                                                        <div class="col-sm-8">
														<select name="tax_type"  class="form-control" >
                                                                <option value="<?php echo $c['tax_type']?>"><?php echo $c['tax_type']?></option>
    <?php
                                                                $tax=mysqli_query($con,"select * from tax ORDER BY title ASC");
                                                                while($r=mysqli_fetch_array($tax)){
                                                                    ?>
                                                                    <option value="<?php echo $r['title']?>"><?php echo $r['title']?></option>
                                                                  <?php 
                                                                }
                                                                ?>
															</select>
														
         
                                                            
                                                         </div>
        
                                                    </div>

                                      
                                                    <div class="form-group">
        
                                                        <label class="col-sm-4 control-label">Status :</label>
        
                                                        <div class="col-sm-8">
														<select name="status" class="form-control">
														<option value="Active">Active</option>
														<option value="InActive">InActive</option>
														</select>
        
                                                             
                                                       	</div>
        
                                                    </div>

                                                 
													
													<div class="form-group">
    
                                                        <label class="col-sm-4 control-label">ID Vendor :</label>
        
                                                        <div class="col-sm-8">
														
														<select name="id_vendor"  class="form-control" >
                                                                <option value="<?php echo $c['id_vendor']?>"><?php echo $c['id_vendor']?></option>
    <?php
                                                                $vendor=mysqli_query($con,"select * from vendors ORDER BY vindor_id ASC");
                                                                while($v=mysqli_fetch_array($vendor)){
                                                                    ?>
                                                                    <option value="<?php echo $v['vindor_id']?>"><?php echo $v['vindor_id']?></option>
                                                                  <?php 
                                                                }
                                                                ?>
															</select>
														
        
                                                             
                                                       	</div>
        
                                                    </div>
													
													<div class="form-group">
    
                                                        <label class="col-sm-4 control-label">Purchase Price:</label>
        
                                                        <div class="col-sm-8">
        
                                                            <input  class="form-control" step="0.01" name="purchase_price" value="<?php echo $c['purchase_price']?>" type="number"> 
                                                       	</div>
        
                                                    </div>
													
													
													<div class="form-group">
    
                                                        <label class="col-sm-4 control-label">Sale Price:</label>
        
                                                        <div class="col-sm-8">
        
                                                            <input  class="form-control" step="0.01" name="sale_price"  value="<?php echo $c['sale_price']?>" type="number"> 
                                                       	</div>
        
                                                    </div>
													
													<div class="form-group">
    
                                                        <label class="col-sm-4 control-label"> Sale Price Dealer:</label>
        
                                                        <div class="col-sm-8">
        
                                                            <input  class="form-control" step="0.01" name="sale_dealer_price" value="<?php echo $c['sale_dealer_price']?>" type="number"> 
                                                       	</div>
        
                                                    </div>
													
													<div class="form-group">

                                                
                                                
                                              <label class="col-sm-4 control-label">Picture:<br /><br /><input id="camera-btn" class="btn sbold green" style=" margin:0 auto;" type=button value="Camera" onClick="attach_webcam()">
                                                <input id="photo-btn" class="btn sbold green" style="display:none; margin:0 auto;" type=button value="Photo" onClick="take_snapshot()"></label>
                                              <div class="col-sm-8" style="text-align:center;" >
                                              	<div id="my_camera">
                                                	<?php 
														if($c['file']!='' ){
															$photo=$c['file'];
															echo '<img src="'.$photo.'"/>';
														}else{
															echo '<img src="img/noimage.png"/>';
															$photo='';
														}
													?>
                                                	
                                                </div>
                                                <textarea name="photo" id="photo" style="display:none;"></textarea>
                                        		
                                               </div>
                                               

                                            </div>
													
													
										</div>
										
                                                
										</div>
										 
											
											
											
                                        <div class="form-actions right1">

                                            <button type="button" class="btn default" onclick="window.location='customers.php'">Cancel</button>

                                            <button type="submit" class="btn green">Save</button>

                                        </div>
                                        
                                        </div>

                                    </form>

									

                                </div>

                            </div>

                        

                        </div>

                    </div>

                    

                    

                    

                    

                    

                    

                    <!-- END PAGE BASE CONTENT -->

                </div>

                <!-- END CONTENT BODY -->

            </div>

            <!-- END CONTENT -->

            <!-- BEGIN QUICK SIDEBAR -->

            

            

            <!-- END QUICK SIDEBAR -->

        </div>

        <!-- END CONTAINER -->

        <!-- BEGIN FOOTER -->

        <?php include('footer.php'); ?>

        

        <!-- END FOOTER -->

        <!-- BEGIN QUICK NAV -->

        <?php //include('quick_nav.php'); ?>

        

        

        <!-- END QUICK NAV -->

        <!--[if lt IE 9]>

<script src="../assets/global/plugins/respond.min.js"></script>

<script src="../assets/global/plugins/excanvas.min.js"></script> 

<script src="../assets/global/plugins/ie8.fix.min.js"></script> 

<![endif]-->

        <!-- BEGIN CORE PLUGINS -->

        <?php include('core_plugins.php'); ?>

        <script src="../assets/global/plugins/bootstrap-fileinput/bootstrap-fileinput.js" type="text/javascript"></script>

        <script src="../assets/global/plugins/bootstrap-datetimepicker/js/bootstrap-datetimepicker.min.js" type="text/javascript"></script>

        <script src="../assets/pages/scripts/components-date-time-pickers.min.js" type="text/javascript"></script>

        <script type="text/javascript">

    		$(".date-picker").datetimepicker({format: 'yyyy-mm-dd hh:ii'});

		</script>
        <script type="text/javascript" src="js/webcam.min.js"></script>
        <script type="text/javascript" src="js/custom.js"></script>

    </body>



</html>