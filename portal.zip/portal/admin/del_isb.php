<?php

include("chksession.php");

include("Common.php");

	mysqli_query($con,"delete from expenses where id='".mysqli_real_escape_string($con,$_GET['id'])."'");

	$_SESSION['msg']="Islamabad Expense has been deleted.";

	mysqli_close($con);	

header("location:expenses_isb.php?name=Islamabad");

?>