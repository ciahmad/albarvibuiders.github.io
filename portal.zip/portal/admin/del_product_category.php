<?php

include("chksession.php");

include("Common.php");

	mysqli_query($con,"delete from product_categories where id='".mysqli_real_escape_string($con,$_GET['id'])."'");

	$_SESSION['msg']="Product Category has been deleted.";

	mysqli_close($con);	

header("location:product_categories.php");

?>