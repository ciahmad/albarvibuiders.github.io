<?php 
include("../chksession.php");

include("../Common.php");

$sql="select projects.id, customers.company, customers.cperson_name, projects.location  from projects LEFT JOIN customers ON projects.id_customer = customers.id where projects.id='".mysqli_real_escape_string($con,$_GET['project_id'])."'";
$customer=mysqli_query($con,$sql);

$c=mysqli_fetch_array($customer);

?>
<html>
	<head>
		<meta charset="utf-8">
		<title>Invoice</title>
		<link rel="stylesheet" href="style.css">
		<link rel="license" href="https://www.opensource.org/licenses/mit-license/">
		<script src="script.js"></script>
	</head>
	<body>
		<header>
			<h1>Qoutation</h1>
			<address contenteditable>
            	<textarea rows="4" cols="25" id="location"><?php echo $c["location"]; ?></textarea>
			</address>
			<span><img alt="" src="../../assets/pages/img/logo-big-white.png" style="width:50%"></span>
		</header>
		<article>
			<h1>Recipient</h1>
			<address contenteditable>
				<!--<input type="text" value="<?php //echo $c["company"]; ?>"><br>
                <input type="text" value="<?php //echo $c["cperson_name"]; ?>" style="margin-top:10px; font-size:16px;">-->
                <p><?php echo $c["company"]; ?></p><br>
                <p><?php echo $c["cperson_name"]; ?></p>
			</address>
			<table class="meta">
				<tr>
					<th><span contenteditable>Date</span></th>
					<td><span contenteditable><?php echo date('D, d M Y'); ?></span></td>
				</tr>
				<tr>
					<th><span contenteditable>Amount Due</span></th>
					<td><span id="prefix" contenteditable>$</span><span>600.00</span></td>
				</tr>
			</table>
			<table class="inventory">
				<thead>
					<tr>
						<th width="35%"><span contenteditable>Item</span></th>
						<th width="35%"><span contenteditable>Description</span></th>
						<th width="15%"><span contenteditable>Rate</span></th>
						<th width="10%"><span contenteditable>Quantity</span></th>
						<th width="15%"><span contenteditable>Price</span></th>
					</tr>
				</thead>
				<tbody>
					<tr>
						<td><a class="cut">-</a><span contenteditable>test pdt</span></td>
						<td><span contenteditable>test product</span></td>
						<td><span data-prefix>$</span><span contenteditable>150</span></td>
						<td><span contenteditable>4</span></td>
						<td><span data-prefix>$</span><span>600.00</span></td>
					</tr>
				</tbody>
			</table>
			<a class="add">+</a>
			<table class="balance">
				<tr>
					<th><span contenteditable>Total</span></th>
					<td><span data-prefix>$</span><span>600.00</span></td>
				</tr>
				<tr>
					<th><span contenteditable>Amount Paid</span></th>
					<td><span data-prefix>$</span><span contenteditable>0.00</span></td>
				</tr>
				<tr>
					<th><span contenteditable>Balance Due</span></th>
					<td><span data-prefix>$</span><span>600.00</span></td>
				</tr>
			</table>
		</article>
		<aside>
			<h1><span contenteditable>Additional Notes</span></h1>
			<div contenteditable>
				<p>A finance charge of 1.5% will be made on unpaid balances after 30 days.</p>
			</div>
		</aside>
	</body>
</html>