<?php 

include("chksession.php");

include("Common.php");

include('header.php');
$sql="select projects.*, customers.company, customers.cperson_name  from projects LEFT JOIN customers ON projects.id_customer = customers.id where projects.id='".mysqli_real_escape_string($con,$_GET['id'])."'";
$customer=mysqli_query($con,$sql);

$c=mysqli_fetch_array($customer);

 ?>

        <!-- BEGIN CONTAINER -->

        <div class="page-container">

            <!-- BEGIN SIDEBAR -->

            <?php include('left_sidebar.php'); ?>

            <!-- END SIDEBAR -->

            <!-- BEGIN CONTENT -->

            <div class="page-content-wrapper">

                <!-- BEGIN CONTENT BODY -->

                <div class="page-content">

                    <!-- BEGIN PAGE HEAD-->

                    <div class="page-head">

                        <!-- BEGIN PAGE TITLE -->

                        <div class="page-title">

                            <h1>Project Management

                                <small>View Project</small>

                            </h1>
                            

                        </div>
                        <div class="btn-group btn-group-justified" style="width:inherit; float:right">
                        	<a class="btn btn-default blue" href="view_project.php?id=<?php echo $c['id']?>" style="width:inherit;"> Details </a>
                        	<a class="btn btn-default" href="project_qoutations.php?id=<?php echo $c['id']?>" style="width:inherit;"> Qoutations </a>
                            <a class="btn btn-default" href="project_resources.php?id=<?php echo $c['id']?>" style="width:inherit;"> Resources </a>
                            <a class="btn btn-default" href="javascript:;" style="width:inherit;"> Expenses </a>
                            <a class="btn btn-default" href="javascript:;" style="width:inherit;"> Right </a>
                      	</div>
                        
                        

                        <!-- END PAGE TITLE -->

                        <!-- BEGIN PAGE TOOLBAR -->

                        

                        <!-- END PAGE TOOLBAR -->

                    </div>

                    <!-- END PAGE HEAD-->

                    <!-- BEGIN PAGE BREADCRUMB -->

                    <ul class="page-breadcrumb breadcrumb">

                        <li>

                            <a href="../../../../admin/projects.php">Project</a>

                            <i class="fa fa-circle"></i>

                        </li>

                        <li>

                            <span class="active">View Project</span>

                        </li>

                    </ul>
                    

                    <!-- END PAGE BREADCRUMB -->

                    <!-- BEGIN PAGE BASE CONTENT -->

                    
					<div class="portlet box blue">
                                <div class="portlet-title">
                                    <div class="caption">
                                        <i class="fa fa-gift"></i>View Project </div>
                                    <div class="tools">
                                        <a class="collapse" href="javascript:;" data-original-title="" title=""> </a>
                                        <a class="config" data-toggle="modal" href="#portlet-config" data-original-title="" title=""> </a>
                                    </div>
                                </div>
                                <div class="portlet-body">
                                    <div class="tabbable-custom ">
                                        <ul class="nav nav-tabs ">
                                            <li class="active">
                                                <a data-toggle="tab" href="#project_info" aria-expanded="true"> Project Info </a>
                                            </li>
                                            <!--<li class="">
                                                <a data-toggle="tab" href="#qoutations" aria-expanded="false"> Qoutations </a>
                                            </li>
                                            <li class="">
                                                <a data-toggle="tab" href="#tab_5_3" aria-expanded="false"> Section 3 </a>
                                            </li>-->
                                        </ul>
                                        <div class="tab-content">
                                            <div id="project_info" class="tab-pane active">
                                               <div class="portlet-body form">

                                   <?php

									//echo $sql;

										if(isset($_SESSION['msg']) && $_SESSION['msg']!='' ){

										?>

										<div class="alert alert-success display-hide" style="display:block">

											<button class="close" data-close="alert"></button>

											<span><?php echo $_SESSION['msg']; $_SESSION['msg']="";?> </span>

										</div>

										

									<?php

										$_SESSION['msg']='';

										}else if(isset($_SESSION['err']) and $_SESSION['err']!='' ){

										?>

										<div class="alert alert-danger  display-hide" style="display:block">

											<button class="close" data-close="alert"></button>

											<span><?php echo $_SESSION['err']; $_SESSION['err']="";?> </span>

										</div>

										

									<?php

										$_SESSION['err']='';

										}

									?>

                                    <form class="form-horizontal"  role="form" action="" enctype="multipart/form-data">

                                        <div class="form-body">
										
											<div class="row">
                                            	<div class="col-sm-7">
                                                <div class="form-group">

                                                		<label class="col-sm-4 control-label">Title:</label>
                                                		<div class="col-sm-8">
														<input class="form-control" disabled="disabled" name="company" value="<?php echo $c['title']?>" type="text">
                                              			
                                                        </div>
                                            		</div>
                                                	
                                                    
                                                    <div class="form-group">
        
                                                        <label class="col-sm-4 control-label">Contact Person Name:</label>
        
                                                        <div class="col-sm-8">
        
                                                            <input name="cperson_name" class="form-control" disabled="disabled" value="<?php echo $c['cperson_name']?>" type="text"> 
                                                            
                                                         </div>
        
                                                    </div>
											
                                                    
											
											
                                                    <div class="form-group">
        
                                                        <label class="col-sm-4 control-label">Location:</label>
                                                        <div class="col-sm-8">
        
                                                      <input class="form-control" disabled="disabled" name="address" value="<?php echo $c['location']?>" type="text"> </div>
        
                                                    </div>
                                                    
                                                    
                                                    
                                                    

                                            
										</div>
										
                                                
                                            	<div class="col-sm-5">
                                                
                                                	
                                                    
                                                    
											
                                                    
											
													<div class="form-group">
        
                                                        <label class="col-sm-4 control-label">Status</label>
                                                        <div class="col-sm-8">
        
                                                      <input class="form-control" disabled="disabled" name="create_at" value="<?php echo $c['status']?>" type="text"> </div>
                                                  	</div>
                                                    
                                                    <div class="form-group">

                                                		<label class="col-sm-4 control-label">Company :</label>
                                                		<div class="col-sm-8">

                                              			<input class="form-control" disabled="disabled" name="phone" value="<?php echo $c['company']?>" type="text"> 
                                                        </div>
                                            		</div>
                                                    
                                                    
                                                    
                                                    
                                                    <div class="form-group">
        
                                                        <label class="col-sm-4 control-label">Create At:</label>
                                                        <div class="col-sm-8">
        
                                                      <input class="form-control" disabled="disabled" name="create_at" value="<?php echo $c['create_dt']?>" type="text"> </div>
        
                                                    </div>

                                            
										</div>
										
                                                
										</div>
										 
											
											
											
                                        
                                        
                                        </div>
                                        

                                    </form>

									

                                </div>
                                            </div>
                                            <div id="qoutations" class="tab-pane">
                                                
                                            </div>
                                            <div id="tab_5_3" class="tab-pane">
                                                <p> Howdy, I'm in Section 3. </p>
                                                <p> Duis autem vel eum iriure dolor in hendrerit in vulputate. Ut wisi enim ad minim veniam, quis nostrud exerci tation ullamcorper suscipit lobortis nisl ut aliquip ex ea commodo consequat. Duis autem vel eum
                                                    iriure dolor in hendrerit in vulputate velit esse molestie consequat </p>
                                                <p>
                                                    <a target="_blank" href="ui_tabs_accordions_navs.html#tab_5_3" class="btn yellow"> Activate this tab via URL </a>
                                                </p>
                                            </div>
                                        </div>
                                    </div>
                                    
                                </div>
                            </div>
                    

                    

                    

                    

                    

                    

                    

                    <!-- END PAGE BASE CONTENT -->

                </div>

                <!-- END CONTENT BODY -->

            </div>

            <!-- END CONTENT -->

            <!-- BEGIN QUICK SIDEBAR -->

            

            

            <!-- END QUICK SIDEBAR -->

        </div>

        <!-- END CONTAINER -->

        <!-- BEGIN FOOTER -->

        <?php include('footer.php'); ?>

        

        <!-- END FOOTER -->

        <!-- BEGIN QUICK NAV -->

       
        
        <!-- END QUICK NAV -->

        <!--[if lt IE 9]>

<script src="../assets/global/plugins/respond.min.js"></script>

<script src="../assets/global/plugins/excanvas.min.js"></script> 

<script src="../assets/global/plugins/ie8.fix.min.js"></script> 

<![endif]-->

        <!-- BEGIN CORE PLUGINS -->

        <?php include('core_plugins.php'); ?>

        <script src="../../../../assets/global/plugins/bootstrap-fileinput/bootstrap-fileinput.js" type="text/javascript"></script>

        <script src="../../../../assets/global/plugins/bootstrap-datetimepicker/js/bootstrap-datetimepicker.min.js" type="text/javascript"></script>

        <script src="../../../../assets/pages/scripts/components-date-time-pickers.min.js" type="text/javascript"></script>

        <script type="text/javascript">

    		$(".date-picker").datetimepicker({format: 'yyyy-mm-dd hh:ii'});

		</script>
	
	<!-- Configure a few settings and attach camera -->

    </body>



</html>