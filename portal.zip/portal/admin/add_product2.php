<?php
include("chksession.php");

include("Common.php");
//$tt=date("Ymdhis");

		 
			$sql="insert into products set p_code='".mysqli_real_escape_string($con,$_POST['p_code'])."',name='".mysqli_real_escape_string($con,$_POST['name'])."',detail='".mysqli_real_escape_string($con,$_POST['detail'])."',id_category='".mysqli_real_escape_string($con,$_POST['id_category'])."',tax_type='".mysqli_real_escape_string($con,$_POST['tax_type'])."',id_vendor='".mysqli_real_escape_string($con,$_POST['id_vendor'])."',purchase_price=".mysqli_real_escape_string($con,$_POST['purchase_price']).",sale_price=".mysqli_real_escape_string($con,$_POST['sale_price']).",sale_dealer_price=".mysqli_real_escape_string($con,$_POST['sale_dealer_price']).",status='".mysqli_real_escape_string($con,$_POST['status'])."',file='".mysqli_real_escape_string($con,$_POST['photo'])."'";
			//echo $sql;
			mysqli_query($con,$sql);

$_SESSION['msg']="Product has been created.";
	mysqli_close($con);	
	
	header('location:products.php');
	



?>