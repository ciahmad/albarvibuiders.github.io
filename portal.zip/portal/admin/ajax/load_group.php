<?php
include("../chksession.php");
include("../Common.php");
$group=$_GET['g'];


	

?>
	<select class="form-control" name="send_to" id="send_to">
    <option value="0">All</option>
    <?php
	if($group=='Players'){
			$players=mysqli_query($con,"select * from players order by first_name");
			while($c=mysqli_fetch_array($players)){
				?>
				<option value="<?php echo $c['id'];?>"><?php echo $c['first_name'];?>&nbsp;<?php echo $c['last_name'];?></option>
			<?php
			}
	}else if($group=='Team'){
			$teams=mysqli_query($con,"select * from teams order by team_name");
			while($c=mysqli_fetch_array($teams)){
				?>
				<option value="<?php echo $c['id'];?>"><?php echo $c['team_name'];?></option>
			<?php
			}
	}else{
		$teams=mysqli_query($con,"select * from company order by name");
			while($c=mysqli_fetch_array($teams)){
				?>
				<option value="<?php echo $c['id'];?>"><?php echo $c['name'];?></option>
			<?php
			}
			
	}
    ?>
    </select>