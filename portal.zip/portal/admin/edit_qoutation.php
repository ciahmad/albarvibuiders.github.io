<?php 

include("chksession.php");

include("Common.php");

include('header.php');
$sql="select * from qoutations where id='".mysqli_real_escape_string($con,$_GET['qoutation_id'])."'";
//$result=mysqli_query($con,$sql);



 ?>

        <!-- BEGIN CONTAINER -->

        <div class="page-container">

            <!-- BEGIN SIDEBAR -->

            <?php include('left_sidebar.php'); ?>

            <!-- END SIDEBAR -->

            <!-- BEGIN CONTENT -->

            <div class="page-content-wrapper">

                <!-- BEGIN CONTENT BODY -->

                <div class="page-content">

                    <!-- BEGIN PAGE HEAD-->

                    <div class="page-head">

                        <!-- BEGIN PAGE TITLE -->

                        <div class="page-title">

                            <h1>Project Management

                                <small>View Project</small>

                            </h1>
                            

                        </div>
                        <div class="btn-group btn-group-justified" style="width:inherit; float:right">
                        	<a class="btn btn-default" href="view_project.php?id=<?php echo $_GET['id'];?>" style="width:inherit;"> Details </a>
                        	<a class="btn btn-default blue" href="project_qoutations.php?id=<?php echo $_GET['id'];?>" style="width:inherit;"> Qoutations </a>
                            <a class="btn btn-default" href="project_resources.php?id=<?php echo $c['id']?>" style="width:inherit;"> Resources </a>
                            <a class="btn btn-default" href="javascript:;" style="width:inherit;"> Expenses </a>
                            <a class="btn btn-default" href="javascript:;" style="width:inherit;"> Right </a>
                      	</div>
                        
                        

                        <!-- END PAGE TITLE -->

                        <!-- BEGIN PAGE TOOLBAR -->

                        

                        <!-- END PAGE TOOLBAR -->

                    </div>

                    <!-- END PAGE HEAD-->

                    <!-- BEGIN PAGE BREADCRUMB -->

                    <ul class="page-breadcrumb breadcrumb">

                        <li>

                            <a href="../../../../admin/projects.php">Project</a>

                            <i class="fa fa-circle"></i>

                        </li>

                        <li>

                            <span class="active">View Project</span>

                        </li>

                    </ul>
                    

                    <!-- END PAGE BREADCRUMB -->

                    <!-- BEGIN PAGE BASE CONTENT -->

                    
					
                    
                    <div class="portlet box blue">
                                <div class="portlet-title">
                                    <div class="caption">
                                        <i class="fa fa-gift"></i>Qoutations </div>
                                    <div class="tools">
                                        <a class="collapse" href="javascript:;" data-original-title="" title=""> </a>
                                        <a class="config" data-toggle="modal" href="#portlet-config" data-original-title="" title=""> </a>
                                    </div>
                                </div>
                                <div class="portlet-body">
                                <?php

									//echo $sql;

										if(isset($_SESSION['msg']) && $_SESSION['msg']!='' ){

										?>

										<div class="alert alert-success display-hide" style="display:block">

											<button class="close" data-close="alert"></button>

											<span><?php echo $_SESSION['msg']; $_SESSION['msg']="";?> </span>

										</div>

										

									<?php

										$_SESSION['msg']='';

										}else if(isset($_SESSION['err']) && $_SESSION['err']!='' ){

										?>

										<div class="alert alert-danger  display-hide" style="display:block">

											<button class="close" data-close="alert"></button>

											<span><?php echo $_SESSION['err']; $_SESSION['err']="";?> </span>

										</div>

										

									<?php

										$_SESSION['err']='';

										}

									?>
                                    <div class="tabbable-custom ">
                                        <ul class="nav nav-tabs ">
                                            <li class="active">
                                                <a data-toggle="tab" href="#qoutation" aria-expanded="true"> Edit Qoutation </a>
                                            </li>
                                            <!--<li class="">
                                                <a data-toggle="tab" href="#tab_5_2" aria-expanded="false"> Section 2 </a>
                                            </li>-->
                                            
                                        </ul>
                                        <div class="tab-content">
                                            
                                            <!--<div id="tab_5_2" class="tab-pane">
                                                <p> Howdy, I'm in Section 2. </p>
                                                <p> Ut wisi enim ad minim veniam, quis nostrud exerci tation ullamcorper suscipit lobortis nisl ut aliquip ex ea commodo consequat. Duis autem vel eum iriure dolor in hendrerit in vulputate velit esse molestie
                                                    consequat. Ut wisi enim ad minim veniam, quis nostrud exerci tation. </p>
                                                <p>
                                                    <a target="_blank" href="ui_tabs_accordions_navs.html#tab_5_2" class="btn green"> Activate this tab via URL </a>
                                                </p>
                                            </div>-->
                                            <?php
											//echo $sql;
                                           $result=mysqli_query($con,$sql);

											$row=mysqli_fetch_array($result);
                                            ?>
                                            <div id="qoutation" class="tab-pane active">
                         <form class="form-horizontal" method="post" role="form" action="edit_qoutation2.php?project_id=<?php echo mysqli_real_escape_string($con,$_GET['id']); ?>&qoutation_id=<?php echo mysqli_real_escape_string($con,$_GET['qoutation_id']); ?>" enctype="multipart/form-data">

                                        <div class="form-body">
										
											<div class="row">
                                            
                                            	<div class="col-sm-6">
                                                <div class="form-group">

                                                		<label class="col-sm-4 control-label">Title:</label>
                                                		<div class="col-sm-8">
														<input class="form-control" name="title" value="<?php echo $row["project_title"]; ?>" type="text" required >
                                              			
                                                        </div>
                                            		</div>
                                                	
											
                                                    <div class="form-group">
        
                                                        <label class="col-sm-4 control-label">Customer:</label>
        
                                                        <div class="col-sm-8">
                                                        	
                                                            <input class="form-control" name="customer_name" value="<?php echo $row["project_customer"]; ?>" type="text" required >
        
                                                         </div>
        
                                                    </div>
                                                    
                                                    

                                            
										</div>
                                        		<div class="col-sm-6">
                                                
                                                    
                                                    <div class="form-group">
        
                                                        <label class="col-sm-4 control-label">Company:</label>
        
                                                        <div class="col-sm-8">
                                                        	
                                                            <input class="form-control" name="company" value="<?php echo $row["project_company"]; ?>" type="text" required >
        
                                                         </div>
        
                                                    </div>
                                                    
											
											
                                                    <div class="form-group">
        
                                                        <label class="col-sm-4 control-label">Location:</label>
                                                        <div class="col-sm-8">
        
                                                      <input class="form-control" name="location" value="<?php echo $row["project_location"]; ?>" type="text" required > </div>
        
                                                    </div>

                                            
										</div>
										
                                                
										</div>
                                        
										 
										<div class="panel panel-default form-panel">

  <div class="panel-heading"> Projects items</div>
  <div class="panel-body">

    <div class="row">
      <div class="col-md-1">
        <h5 class="bold center">Delete</h5>
      </div>

      <div class="col-md-3">
        <h5 class="bold center">Select Item</h5>
      </div>


      <div class="col-md-3">
        <h5 class="bold">Item Name</h5>
      </div>

      <div class="col-md-2">
        <h5 class="bold">Rate</h5>
      </div>

      <div class="col-md-1">
        <h5 class="bold">Qty</h5>
      </div>

      <div class="col-md-2">
        <h5 class="bold">Total</h5>
      </div>


    </div>

    <ul class="job-item-list no-style-list listis" id="job_item_list" style="padding-left:0; list-style:none;">

    </ul>

    <hr>
    <a class="btn btn-default addLaborToJob"><i class="fa fa-plus"></i></a>
  </div>
</div>

<hr />
<div class="row">

  <div class="col-md-6 col-md-6">
    <label><i class="icon-pencil"></i>&nbsp;Note To Customer</label>
    <textarea class="form-control" id="estimate_note_to_customer_text" name="estimate_note_to_customer_text"></textarea>
  </div>


  <div class="col-md-6 col-md-6 cart-totals">
  	<div class="col-md-6"><h5>Total Price</h5></div>
	<div class="col-md-6"><input class="form-control" name="total_price" id="total_price" value="<?php echo $row["total_amount"]; ?>" type="text"></div>
	<div class="col-md-6"><h5>Tax</h5></div>
	<div class="col-md-6"><input class="form-control" name="total_tax" id="total_tax" value="<?php echo $row["total_tax"]; ?>" type="text"></div>
    <div class="col-md-6"><h5>Discount</h5></div>
	<div class="col-md-6"><input class="form-control" name="total_discount" id="total_discount" value="<?php echo $row["total_discount"]; ?>" type="text"></div>
	<div class="col-md-6"><h5>Deposits</h5></div>
	<div class="col-md-6"><input class="form-control" name="total_paid" id="total_paid" value="<?php echo $row["total_paid"]; ?>" type="text" ></div>
	<div class="col-md-6"><h5>Remaining</h5></div>
	<div class="col-md-6"><input class="form-control" name="gross_amount" id="remaining" value="<?php echo $row["gross_amount"]; ?>" type="text" ></div>


  </div>

  <!--End 4 Row -->
</div>


                                        
                                        
                                        <div style="clear:both"></div>	
											
                                        <div class="form-actions right1">

                                            <button type="button" class="btn default" onclick="window.location='projects.php'">Cancel</button>

                                            <button type="submit" class="btn green">Save</button>

                                        </div>
                                        
                                        </div>

                                    </form>
                                            </div>
                                        </div>
                                    </div>
                                    
                                </div>
                            </div>
                            

                    <!-- END PAGE BASE CONTENT -->

                </div>

                <!-- END CONTENT BODY -->

            </div>

            <!-- END CONTENT -->

            <!-- BEGIN QUICK SIDEBAR -->

            

            

            <!-- END QUICK SIDEBAR -->

        </div>

        <!-- END CONTAINER -->

        <!-- BEGIN FOOTER -->

        <?php include('footer.php'); ?>

        

        <!-- END FOOTER -->

        <!-- BEGIN QUICK NAV -->
       <?php
	    $items_array = array();;
	   	$q="select * from qoutation_items where qoutation_id='".mysqli_real_escape_string($con,$_GET['qoutation_id'])."'";
	   	$result2=mysqli_query($con,$q);
		//$r=mysqli_fetch_array($result2);
		
    	while($r=mysqli_fetch_array($result2)) {
        $item_array =array("uid"=>rand(),"p_id"=>$r['product_id'],"p_name"=>$r['product_name'],"p_rate"=>$r['product_rate'],"p_qty"=>$r['product_qty'],"p_total"=>$r['product_price'],"product"=>array("id"=>$r['product_id'],"rate"=>$r['product_rate'],"name"=>$r['product_name']));
			array_push($items_array,$item_array);
    	}
    //convert the PHP array into JSON format, so it works with javascript
    $json_array = json_encode($items_array);
	//echo $json_array;
	   
	   ?>
       
        
        <!-- END QUICK NAV -->

        <!--[if lt IE 9]>

<script src="../assets/global/plugins/respond.min.js"></script>

<script src="../assets/global/plugins/excanvas.min.js"></script> 

<script src="../assets/global/plugins/ie8.fix.min.js"></script> 

<![endif]-->

        <!-- BEGIN CORE PLUGINS -->

        <?php include('core_plugins.php'); ?>

        <script src="js/product.js" type="text/javascript"></script>
  		<script src="js/bootstrap-chosen.js" type="text/javascript"></script>
		<script>
		$(document).ready(function(){
			jobcart.changeAmount('tax',<?php echo $row["total_tax"]; ?>);
			jobcart.changeAmount('paid',<?php echo $row["total_paid"]; ?>);
			jobcart.changeAmount('discount',<?php echo $row["total_discount"]; ?>);
		 	jobcart.replaceItems(<?php echo $json_array;?>);
		 });
	 </script>


    </body>



</html>