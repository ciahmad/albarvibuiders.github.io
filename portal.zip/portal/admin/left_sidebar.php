<?php

$page=explode('/admin/',$_SERVER['REQUEST_URI']);
$p=explode('.php',$page[1]);
$p=$p[0];
$active='active open';


?>

<div class="page-sidebar-wrapper">

                <!-- BEGIN SIDEBAR -->

                <!-- DOC: Set data-auto-scroll="false" to disable the sidebar from auto scrolling/focusing -->

                <!-- DOC: Change data-auto-speed="200" to adjust the sub menu slide up/down speed -->

                <div class="page-sidebar navbar-collapse collapse">

                    <!-- BEGIN SIDEBAR MENU -->

                    <!-- DOC: Apply "page-sidebar-menu-light" class right after "page-sidebar-menu" to enable light sidebar menu style(without borders) -->

                    <!-- DOC: Apply "page-sidebar-menu-hover-submenu" class right after "page-sidebar-menu" to enable hoverable(hover vs accordion) sub menu mode -->

                    <!-- DOC: Apply "page-sidebar-menu-closed" class right after "page-sidebar-menu" to collapse("page-sidebar-closed" class must be applied to the body element) the sidebar sub menu mode -->

                    <!-- DOC: Set data-auto-scroll="false" to disable the sidebar from auto scrolling/focusing -->

                    <!-- DOC: Set data-keep-expand="true" to keep the submenues expanded -->

                    <!-- DOC: Set data-auto-speed="200" to adjust the sub menu slide up/down speed -->

                    <ul class="page-sidebar-menu   " data-keep-expanded="false" data-auto-scroll="true" data-slide-speed="200">

                        <li class="nav-item start <?php if($p=="welcome"){echo $active;}?>">

                            <a href="welcome.php" class="nav-link ">

                                <i class="icon-home"></i>

                                <span class="title">Dashboard</span>

                                <span class="selected"></span>

                            </a>
                        </li>
                        <?php 
                      //  echo $_SESSION['login_site']; die();
						    if($_SESSION['login_role']=="Admin" or $_SESSION['login_site']=="Multan"){
						?>

                                <li class="nav-item start <?php if($p=="expenses" or $p=="add_expense" or $p=="multan_transfer" or $p=="add_multan_transfer" or $p=="edit_expense" or $p=="view_expense"){echo $active;}?>">
                                    <a href="javascript:;" class="nav-link nav-toggle">
                                        <i class="icon-layers"></i>
                                        <span class="title">MULTAN OFFICE</span>
                                        <span class="selected"></span>
                                        <span class="arrow open"></span>
                                    </a>

                                    <ul class="sub-menu">
                                        <li class="nav-item start <?php if($p=="expenses"){echo 'active';}?>">
                                            <a href="expenses.php?name=Multan" target=""  class="nav-link">
                                                <i class="fa fa-list"></i>
                                                <span class="title">Expense List</span>
                                            </a>
                                        </li>

                                        <li class="nav-item start <?php if($p=="add_expense"){echo 'active';}?>">
                                            <a href="add_expense.php" class="nav-link ">
                                                <i class="fa fa-plus"></i>
                                                <span class="title">New Expense</span>
                                            </a>
                                        </li>                
                                    </ul>


                                    <ul class="sub-menu">
                                        <li class="nav-item start <?php if($p=="expenses"){echo 'active';}?>">
                                            <a href="multan_transfer.php?name=Multan" target=""  class="nav-link">
                                                <i class="fa fa-list"></i>
                                                <span class="title">Transfer List</span>
                                            </a>
                                        </li>

                                        <li class="nav-item start <?php if($p=="add_expense"){echo 'active';}?>">
                                            <a href="add_multan_transfer.php" class="nav-link ">
                                                <i class="fa fa-plus"></i>
                                                <span class="title">New Transfer</span>
                                            </a>
                                        </li>                
                                    </ul>
                                </li>
			
						<?php
							}
							if($_SESSION['login_role']=="Admin" or $_SESSION['login_site']=="Islamabad"){
						?>
						<li class="nav-item start <?php if($p=="expenses_isb" or $p=="add_expense_islamabad"){echo $active;}?>">
                            <a href="javascript:;" class="nav-link nav-toggle">
                                <i class="icon-layers"></i>
                                <span class="title">ISLAMABAD OFFICE</span>
                                <span class="selected"></span>
                                <span class="arrow open"></span>
                            </a>

                            <ul class="sub-menu">
                                <li class="nav-item start <?php if($p=="expenses_isb"){echo 'active';}?>">
                                    <a href="expenses_isb.php?name=Islamabad" target="" class="nav-link ">
                                        <i class="fa fa-list"></i>
                                        <span class="title">Expense List</span>
                                    </a>
                                </li>

								<li class="nav-item start <?php if($p=="add_expense_islamabad"){echo 'active';}?>">
                                    <a href="add_expense_islamabad.php" class="nav-link ">
                                        <i class="fa fa-plus"></i>
                                        <span class="title">Add Expense</span>
                                    </a>
                                </li>
                            </ul>
                        </li>

                        
						<?php } if($_SESSION['login_role']=="Admin" or $_SESSION['login_site']=="Karachi"){ ?>
							
                        
                            <li class="nav-item start <?php if($p=="expenses_khi" or $p=="add_expense_karachi"){echo $active;}?>">
                                <a href="javascript:;" class="nav-link nav-toggle">
                                    <i class="icon-layers"></i>
                                    <span class="title">KARACHI OFFICE</span>
                                    <span class="selected"></span>
                                    <span class="arrow open"></span>
                                </a>

                                <ul class="sub-menu">
                                    <li class="nav-item start <?php if($p=="expenses_khi"){echo 'active';}?>">
                                        <a href="expenses_khi.php?name=Karachi" class="nav-link ">
                                            <i class="fa fa-list"></i>
                                            <span class="title">Expense List</span>
                                        </a>
                                    </li>

                                    <li class="nav-item start <?php if($p=="add_expense_karachi"){echo 'active';}?>">
                                        <a href="add_expense_karachi.php" class="nav-link ">
                                            <i class="fa fa-plus"></i>
                                            <span class="title">Add Expense</span>
                                        </a>
                                    </li>
                                </ul>
                            </li>

                         <?php } if($_SESSION['login_role']=="Admin"){ ?>
                            <li class="nav-item start <?php if($p=="users" or $p=="add_user" or $p=="edit_user"){echo $active;}?>">
                                <a href="javascript:;" class="nav-link nav-toggle">
                                    <i class="icon-user"></i>
                                    <span class="title">System Users</span>
                                    <span class="selected"></span>
                                    <span class="arrow open"></span>
                                </a>

                                <ul class="sub-menu">
                                    <li class="nav-item start <?php if($p=="users"){echo 'active';}?>">
                                        <a href="users.php" class="nav-link ">
                                            <i class="fa fa-list"></i>
                                            <span class="title">Users List</span>
                                        </a>
                                    </li>

                                    <li class="nav-item start <?php if($p=="add_user"){echo 'active';}?>">
                                        <a href="add_user.php" class="nav-link ">
                                            <i class="fa fa-plus"></i>
                                            <span class="title">Add User</span>
                                        </a>
                                    </li>
                                </ul>
                            </li>
                            <?php } ?> 
                    </ul>


                </div>

                <!-- END SIDEBAR -->

            </div>
            
 