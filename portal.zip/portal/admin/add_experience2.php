<?php
//$con = mysqli_connect("localhost","root","","cantt_entry");
include("chksession.php");

include("Common.php");
//$tt=date("Ymdhis");
			
			
			$result= mysqli_query($con,"insert into employees_experience set emp_id='".mysqli_real_escape_string($con,$_POST['emp_id'])."',designation='".mysqli_real_escape_string($con,$_POST['designation'])."',emp_from='".mysqli_real_escape_string($con,$_POST['emp_from'])."',emp_to='".mysqli_real_escape_string($con,$_POST['emp_to'])."',location='".mysqli_real_escape_string($con,$_POST['location'])."',country='".mysqli_real_escape_string($con,$_POST['country'])."',compnay_name='".mysqli_real_escape_string($con,$_POST['company_name'])."',total_experience='".mysqli_real_escape_string($con,$_POST['total_experience'])."'");
			
			

			$_SESSION['msg']="Employee Experience has been created.";


			mysqli_close($con);		

	header('location:employees.php');



?>