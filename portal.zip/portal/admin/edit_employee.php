<?php 

include("chksession.php");

include("Common.php");

include('header.php');

$employees=mysqli_query($con,"select * from employees where id='".mysqli_real_escape_string($con,$_GET['id'])."'");

$e=mysqli_fetch_array($employees);

 ?>

        <!-- BEGIN CONTAINER -->

        <div class="page-container">

            <!-- BEGIN SIDEBAR -->

            <?php include('left_sidebar.php'); ?>

            <!-- END SIDEBAR -->

            <!-- BEGIN CONTENT -->

            <div class="page-content-wrapper">

                <!-- BEGIN CONTENT BODY -->

                <div class="page-content">

                    <!-- BEGIN PAGE HEAD-->

                    <div class="page-head">

                        <!-- BEGIN PAGE TITLE -->

                        <div class="page-title">

                            <h1>Employees Management

                                <small>Add Employee</small>

                            </h1>

                        </div>

                        <!-- END PAGE TITLE -->

                        <!-- BEGIN PAGE TOOLBAR -->

                        

                        <!-- END PAGE TOOLBAR -->

                    </div>

                    <!-- END PAGE HEAD-->

                    <!-- BEGIN PAGE BREADCRUMB -->

                    <ul class="page-breadcrumb breadcrumb">

                        <li>

                            <a href="employees.php">Employee</a></li>

                        <li>

                            <span class="active">Add New Employee</span>

                        </li>

                    </ul>

                    <!-- END PAGE BREADCRUMB -->

                    <!-- BEGIN PAGE BASE CONTENT -->

                    

                    <div class="row">

                    	<div class="col-sm-12">

                        	<div class="portlet box blue ">

                                <div class="portlet-title">

                                    <div class="caption">

                                        <i class="fa fa-gift"></i>Create New Employee</div>

                                   
                                </div>

                                <div class="portlet-body form">

                                    <!--<form role="form">

                                        <div class="form-body">

                                            <div class="form-group has-success">

                                                <label class="control-label">Input with success</label>

                                                <input type="text" class="form-control" id="inputSuccess"> </div>

                                            <div class="form-group has-warning">

                                                <label class="control-label">Input with warning</label>

                                                <input type="text" class="form-control" id="inputWarning"> </div>

                                            <div class="form-group has-error">

                                                <label class="control-label">Input with error</label>

                                                <input type="text" class="form-control" id="inputError"> </div>

                                        </div>

                                        <div class="form-actions">

                                            <button type="button" class="btn default">Cancel</button>

                                            <button type="submit" class="btn red">Submit</button>

                                        </div>

                                    </form>-->

                                    <form class="form-horizontal" method="post" role="form" action="edit_employee2.php?id=<?php echo $e['id']?>" enctype="multipart/form-data">

                                        <div class="form-body">
										
											<div class="row">
                                            	<div class="col-sm-6">
                                                <div class="form-group">

                                                		<label class="col-sm-4 control-label">Emp ID:</label>
                                                		<div class="col-sm-8">
														<input class="form-control" name="emp_id" value="<?php echo $e['emp_id']?>" type="text">
                                              			
                                                        </div>
                                            		</div>
                                                	<div class="form-group">

                                                		<label class="col-sm-4 control-label">Emp Name :</label>
                                                		<div class="col-sm-8">

                                              			<input class="form-control" name="name" value="<?php echo $e['name']?>" type="text"> 
                                                        </div>
                                            		</div>
											
                                                    <div class="form-group">
        
                                                        <label class="col-sm-4 control-label">Father Name:</label>
                                                        <div class="col-sm-8">
        
                                                      <input class="form-control" name="father_name" value="<?php echo $e['father_name']?>" type="text"> </div>
        
                                                    </div>
											
											
                                                    <div class="form-group">
        
                                                        <label class="col-sm-4 control-label">Emp CNIC:</label>
                                                        <div class="col-sm-8">
        
                                                      <input class="form-control" name="cnic" value="<?php echo $e['cnic']?>" type="text"> </div>
        
                                                    </div>

										

                                                    <div class="form-group">
        
                                                        <label class="col-sm-4 control-label">Emp Phone:</label>
        
                                                        <div class="col-sm-8">
        
                                                            <input name="phone" class="form-control" value="<?php echo $e['phone']?>" type="text"> 
                                                            
                                                         </div>
        
                                                    </div>

                                      
                                                    <div class="form-group">
        
                                                        <label class="col-sm-4 control-label">Emp DOB:</label>
        
                                                        <div class="col-sm-8">
        
                                                            <input name="dob" class="form-control" value="<?php echo $e['dob']?>" type="date"> 
                                                       	</div>
        
                                                    </div>

                                                    <div class="form-group">
    
                                                        <label class="col-sm-4 control-label">Emp Designation:</label>
        
                                                        <div class="col-sm-8">
        
                                                            <input name="designation" class="form-control" value="<?php echo $e['designation']?>" type="text"> 
                                                       	</div>
        
                                                    </div>
                                            
                                            		<div class="form-group">

                                                		<label class="col-sm-4 control-label">Address:</label>

                                                        <div class="col-sm-8">
        
                                                            <input name="address" class="form-control" value="<?php echo $e['address']?>" type="text"> 
                                                       	</div>
                                                   
                                                    </div>
											
											<div class="form-group">

                                                <label class="col-sm-4 control-label">E-Mail:</label>

                                                <div class="col-sm-8">

                                                    <input name="email" class="form-control" value="<?php echo $e['email']?>" type="text"> </div>
                                           
                                            </div>
                                            
                                            <div class="form-group">

                                                <label class="col-sm-4 control-label">Password:</label>

                                                <div class="col-sm-8">

                                                    <input name="password" class="form-control" value="<?php echo $e['password']?>" type="text"> </div>
                                           
                                            </div>
                                            
                                            <div class="form-group">

                                                <label class="col-sm-4 control-label"> Salary:</label>

                                                <div class="col-sm-8">
													<input type="text" name="salary"  value="<?php echo $e['salary']?>" class="form-control"/>
                                                   
                                                  </div>

                                           </div>

										
										</div>
										
                                                <div class="col-sm-6">
                                                	<div class="form-group">

                                                
                                                
                                              <label class="col-sm-4 control-label">Picture:<br /><br /><input id="camera-btn" class="btn sbold green" style=" margin:0 auto;" type=button value="Camera" onClick="attach_webcam()">
                                                <input id="photo-btn" class="btn sbold green" style="display:none; margin:0 auto;" type=button value="Photo" onClick="take_snapshot()"></label>
                                              <div class="col-sm-8" style="text-align:center;" >
                                              	<div id="my_camera">
                                                	<?php 
														if($e['file']!='' ){
															$photo=$e['file'];
															echo '<img src="'.$photo.'"/>';
														}else{
															echo '<img src="img/noimage.png"/>';
															$photo='';
														}
													?>
                                                	
                                                </div>
                                                <textarea name="photo" id="photo" style="display:none;"><?php echo $photo; ?></textarea>
                                        		
                                               </div>
                                               

                                            </div>
											<div class="form-group">

                                         <label class="col-sm-4 control-label">Bouns:</label>

                                         <div class="col-sm-8">
													
										 <input type="text" name="bouns"  value="<?php echo $e['bouns']?>" class="form-control"/>
                                                   
                                                  </div>

                                            </div>
												
											<div class="form-group">

                                         <label class="col-sm-4 control-label">Medical Allowance:</label>

                                         <div class="col-sm-8">
													
										 <input type="text" name="medical_allowance"  value="<?php echo $e['medical_allowance']?>" class="form-control"/>
                                                   
                                                  </div>

                                            </div>
											
											<div class="form-group">

                                         <label class="col-sm-4 control-label">Allowed Leave:</label>

                                         <div class="col-sm-8">
													
													
													<input type="text" name="allowed_leave" class="form-control" value="<?php echo $e['allowed_leave']?>" />
										 
                                                   
                                                  </div>

                                            </div>
                                            		
												<div class="form-group">

                                         <label class="col-sm-4 control-label">Emergency Contact Person Name:</label>

                                         <div class="col-sm-8">
													
													
													<input type="text" name="emergency_contact_person_name" class="form-control" value="<?php echo $e['emergency_contact_person_name']?>"  />   
                                                  </div>

                                            </div>
											
											<div class="form-group">

                                         <label class="col-sm-4 control-label">Emergency Contact Person NO:</label>

                                         <div class="col-sm-8">
													
										 <input type="text" name="emergency_contact_person_no"  value="<?php echo $e['emergency_contact_person_no']?>" class="form-control"/>
                                                   
                                                  </div>

                                            </div>
											
											 </div>
										
                                            
										</div>
										 
											
											
											
                                        <div class="form-actions right1">

                                            <button type="button" class="btn default" onclick="window.location='employees.php'">Cancel</button>

                                            <button type="submit" class="btn green">Save</button>

                                        </div>
                                        
                                        </div>

                                    </form>

									

                                </div>

                            </div>

                        

                        </div>

                    </div>

                    

                    

                    

                    

                    

                    

                    <!-- END PAGE BASE CONTENT -->

                </div>

                <!-- END CONTENT BODY -->

            </div>

            <!-- END CONTENT -->

            <!-- BEGIN QUICK SIDEBAR -->

            

            

            <!-- END QUICK SIDEBAR -->

        </div>

        <!-- END CONTAINER -->

        <!-- BEGIN FOOTER -->

        <?php include('footer.php'); ?>

        

        <!-- END FOOTER -->

        <!-- BEGIN QUICK NAV -->

        <?php //include('quick_nav.php'); ?>

        

        

        <!-- END QUICK NAV -->

        <!--[if lt IE 9]>

<script src="../assets/global/plugins/respond.min.js"></script>

<script src="../assets/global/plugins/excanvas.min.js"></script> 

<script src="../assets/global/plugins/ie8.fix.min.js"></script> 

<![endif]-->

        <!-- BEGIN CORE PLUGINS -->

        <?php include('core_plugins.php'); ?>

        <script src="../assets/global/plugins/bootstrap-fileinput/bootstrap-fileinput.js" type="text/javascript"></script>

        <script src="../assets/global/plugins/bootstrap-datetimepicker/js/bootstrap-datetimepicker.min.js" type="text/javascript"></script>

        <script src="../assets/pages/scripts/components-date-time-pickers.min.js" type="text/javascript"></script>

        <script type="text/javascript">

    		$(".date-picker").datetimepicker({format: 'yyyy-mm-dd hh:ii'});

		</script>
        <script type="text/javascript" src="js/webcam.min.js"></script>
        <script type="text/javascript" src="js/custom.js"></script>

    </body>



</html>