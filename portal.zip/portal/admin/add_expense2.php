<?php
//$con = mysqli_connect("localhost","root","","cantt_entry");
include("chksession.php");

include("Common.php");
$tt=date("Ymdhis");

			
			$sql="insert into expenses set title='".mysqli_real_escape_string($con,$_POST['title'])."',reg_dt='".$tt."',												
												amount='".mysqli_real_escape_string($con,$_POST['amount'])."',
												description='".mysqli_real_escape_string($con,$_POST['description'])."',
												site='".$_SESSION['login_site']."',
												added_by='".$_SESSION['login_name']."'";
												//echo $sql; die();
												mysqli_query($con,$sql);
										
			$_SESSION['msg']="Multan Expense has been created.";
			mysqli_close($con);		
			header("location:expenses.php?name=Multan");



?>