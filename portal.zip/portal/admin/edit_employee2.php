<?php
//$con = mysqli_connect("localhost","root","","cantt_entry");
include("chksession.php");

include("Common.php");
//$tt=date("Ymdhis");
			
			
			$result= mysqli_query($con,"update employees set emp_id='".mysqli_real_escape_string($con,$_POST['emp_id'])."',name='".mysqli_real_escape_string($con,$_POST['name'])."',father_name='".mysqli_real_escape_string($con,$_POST['father_name'])."',cnic='".mysqli_real_escape_string($con,$_POST['cnic'])."',phone='".mysqli_real_escape_string($con,$_POST['phone'])."',dob='".mysqli_real_escape_string($con,$_POST['dob'])."',designation='".mysqli_real_escape_string($con,$_POST['designation'])."',address='".mysqli_real_escape_string($con,$_POST['address'])."',email='".mysqli_real_escape_string($con,$_POST['email'])."',password='".mysqli_real_escape_string($con,$_POST['password'])."',salary='".mysqli_real_escape_string($con,$_POST['salary'])."',bouns='".mysqli_real_escape_string($con,$_POST['bouns'])."',medical_allowance='".mysqli_real_escape_string($con,$_POST['medical_allowance'])."',allowed_leave='".mysqli_real_escape_string($con,$_POST['allowed_leave'])."',emergency_contact_person_name='".mysqli_real_escape_string($con,$_POST['emergency_contact_person_name'])."',emergency_contact_person_no='".mysqli_real_escape_string($con,$_POST['emergency_contact_person_no'])."',file='".mysqli_real_escape_string($con,$_POST['photo'])."' where id=".$_GET['id']);
			
			

			$_SESSION['msg']="Employee has been created.";


			mysqli_close($con);		

	header('location:employees.php');



?>