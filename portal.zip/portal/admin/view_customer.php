<?php 

include("chksession.php");

include("Common.php");

include('header.php');
$customer=mysqli_query($con,"select * from customers where id='".mysqli_real_escape_string($con,$_GET['id'])."'");

$c=mysqli_fetch_array($customer);

 ?>

        <!-- BEGIN CONTAINER -->

        <div class="page-container">

            <!-- BEGIN SIDEBAR -->

            <?php include('left_sidebar.php'); ?>

            <!-- END SIDEBAR -->

            <!-- BEGIN CONTENT -->

            <div class="page-content-wrapper">

                <!-- BEGIN CONTENT BODY -->

                <div class="page-content">

                    <!-- BEGIN PAGE HEAD-->

                    <div class="page-head">

                        <!-- BEGIN PAGE TITLE -->

                        <div class="page-title">

                            <h1>Customer Management

                                <small>View Customer</small>

                            </h1>

                        </div>

                        <!-- END PAGE TITLE -->

                        <!-- BEGIN PAGE TOOLBAR -->

                        

                        <!-- END PAGE TOOLBAR -->

                    </div>

                    <!-- END PAGE HEAD-->

                    <!-- BEGIN PAGE BREADCRUMB -->

                    <ul class="page-breadcrumb breadcrumb">

                        <li>

                            <a href="../../../../admin/customers.php">Customer</a>

                            <i class="fa fa-circle"></i>

                        </li>

                        <li>

                            <span class="active">View Customer</span>

                        </li>

                    </ul>

                    <!-- END PAGE BREADCRUMB -->

                    <!-- BEGIN PAGE BASE CONTENT -->

                    

                    <div class="row">

                    	<div class="col-sm-12">

                        	<div class="portlet box blue ">

                                <div class="portlet-title">

                                    <div class="caption">

                                        <i class="fa fa-gift"></i>View Customer
                                    </div>

                                   
                                </div>

                                <div class="portlet-body form">

                                   <?php

									//echo $sql;

										if(isset($_SESSION['msg']) && $_SESSION['msg']!='' ){

										?>

										<div class="alert alert-success display-hide" style="display:block">

											<button class="close" data-close="alert"></button>

											<span><?php echo $_SESSION['msg']; $_SESSION['msg']="";?> </span>

										</div>

										

									<?php

										$_SESSION['msg']='';

										}else if(isset($_SESSION['err']) and $_SESSION['err']!='' ){

										?>

										<div class="alert alert-danger  display-hide" style="display:block">

											<button class="close" data-close="alert"></button>

											<span><?php echo $_SESSION['err']; $_SESSION['err']="";?> </span>

										</div>

										

									<?php

										$_SESSION['err']='';

										}

									?>

                                    <form class="form-horizontal"  role="form" action="" enctype="multipart/form-data">

                                        <div class="form-body">
										
											<div class="row">
                                            	<div class="col-sm-6">
                                                <div class="form-group">

                                                		<label class="col-sm-4 control-label">Company Name:</label>
                                                		<div class="col-sm-8">
														<input class="form-control" disabled="disabled" name="company" value="<?php echo $c['company']?>" type="text">
                                              			
                                                        </div>
                                            		</div>
                                                	<div class="form-group">

                                                		<label class="col-sm-4 control-label">Phone No :</label>
                                                		<div class="col-sm-8">

                                              			<input class="form-control" disabled="disabled" name="phone" value="<?php echo $c['phone']?>" type="text"> 
                                                        </div>
                                            		</div>
											
                                                    <div class="form-group">
        
                                                        <label class="col-sm-4 control-label"> E-Mail:</label>
                                                        <div class="col-sm-8">
        
                                                      <input class="form-control" disabled="disabled" name="email" value="<?php echo $c['email']?>" type="email"> </div>
        
                                                    </div>
											
											
                                                    <div class="form-group">
        
                                                        <label class="col-sm-4 control-label">Address:</label>
                                                        <div class="col-sm-8">
        
                                                      <input class="form-control" disabled="disabled" name="address" value="<?php echo $c['address']?>" type="text"> </div>
        
                                                    </div>

										

                                                    <div class="form-group">
        
                                                        <label class="col-sm-4 control-label">Contact Person Name:</label>
        
                                                        <div class="col-sm-8">
        
                                                            <input name="cperson_name" class="form-control" disabled="disabled" value="<?php echo $c['cperson_name']?>" type="text"> 
                                                            
                                                         </div>
        
                                                    </div>

                                      
                                                    <div class="form-group">
        
                                                        <label class="col-sm-4 control-label">Contact Person E-Mail:</label>
        
                                                        <div class="col-sm-8">
        
                                                            <input name="cperson_email" class="form-control" disabled="disabled" value="<?php echo $c['cperson_email']?>" type="email"> 
                                                       	</div>
        
                                                    </div>

                                                    <div class="form-group">
    
                                                        <label class="col-sm-4 control-label">Contact Person Phone:</label>
        
                                                        <div class="col-sm-8">
        
                                                            <input name="cperson_phone" class="form-control" disabled="disabled" value="<?php echo $c['cperson_phone']?>" type="text"> 
                                                       	</div>
        
                                                    </div>
                                            
                                            		<div class="form-group">

                                                		<label class="col-sm-4 control-label">Registration Date:</label>

                                                        <div class="col-sm-8">
        
                                                            <input name="reg_date" class="form-control" disabled="disabled" value="<?php echo $c['reg_date']?>" type="date"> 
                                                       	</div>
                                                   
                                                    </div>
										
                                            
										</div>
										
                                                
										</div>
										 
											
											
											
                                        
                                        
                                        </div>
                                        

                                    </form>

									

                                </div>

                            </div>

                        

                        </div>

                    </div>

                    

                    

                    

                    

                    

                    

                    <!-- END PAGE BASE CONTENT -->

                </div>

                <!-- END CONTENT BODY -->

            </div>

            <!-- END CONTENT -->

            <!-- BEGIN QUICK SIDEBAR -->

            

            

            <!-- END QUICK SIDEBAR -->

        </div>

        <!-- END CONTAINER -->

        <!-- BEGIN FOOTER -->

        <?php include('footer.php'); ?>

        

        <!-- END FOOTER -->

        <!-- BEGIN QUICK NAV -->

       
        
        <!-- END QUICK NAV -->

        <!--[if lt IE 9]>

<script src="../assets/global/plugins/respond.min.js"></script>

<script src="../assets/global/plugins/excanvas.min.js"></script> 

<script src="../assets/global/plugins/ie8.fix.min.js"></script> 

<![endif]-->

        <!-- BEGIN CORE PLUGINS -->

        <?php include('core_plugins.php'); ?>

        <script src="../../../../assets/global/plugins/bootstrap-fileinput/bootstrap-fileinput.js" type="text/javascript"></script>

        <script src="../../../../assets/global/plugins/bootstrap-datetimepicker/js/bootstrap-datetimepicker.min.js" type="text/javascript"></script>

        <script src="../../../../assets/pages/scripts/components-date-time-pickers.min.js" type="text/javascript"></script>

        <script type="text/javascript">

    		$(".date-picker").datetimepicker({format: 'yyyy-mm-dd hh:ii'});

		</script>
	
	<!-- Configure a few settings and attach camera -->

    </body>



</html>