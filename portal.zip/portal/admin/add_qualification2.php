<?php
//$con = mysqli_connect("localhost","root","","cantt_entry");
include("chksession.php");

include("Common.php");
//$tt=date("Ymdhis");
			
			
			$result= mysqli_query($con,"insert into employees_qualification set emp_id='".mysqli_real_escape_string($con,$_POST['emp_id'])."',degree_name='".mysqli_real_escape_string($con,$_POST['degree_name'])."',board_uni='".mysqli_real_escape_string($con,$_POST['board_uni'])."',total_marks='".mysqli_real_escape_string($con,$_POST['total_marks'])."',pass_year='".mysqli_real_escape_string($con,$_POST['pass_year'])."'");
			
			

			$_SESSION['msg']="Employee Qualification has been created.";


			mysqli_close($con);		

	header('location:employees.php');



?>