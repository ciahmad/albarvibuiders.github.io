<?php 

include("chksession.php");

include("Common.php");

include('header.php');
$product=mysqli_query($con,"select * from products where id='".mysqli_real_escape_string($con,$_GET['id'])."'");

$c=mysqli_fetch_array($product);

 ?>

        <!-- BEGIN CONTAINER -->

        <div class="page-container">

            <!-- BEGIN SIDEBAR -->

            <?php include('left_sidebar.php'); ?>

            <!-- END SIDEBAR -->

            <!-- BEGIN CONTENT -->

            <div class="page-content-wrapper">

                <!-- BEGIN CONTENT BODY -->

                <div class="page-content">

                    <!-- BEGIN PAGE HEAD-->

                    <div class="page-head">

                        <!-- BEGIN PAGE TITLE -->

                        <div class="page-title">

                            <h1>Product Management

                                <small>View Product</small>

                            </h1>

                        </div>

                        <!-- END PAGE TITLE -->

                        <!-- BEGIN PAGE TOOLBAR -->

                        

                        <!-- END PAGE TOOLBAR -->

                    </div>

                    <!-- END PAGE HEAD-->

                    <!-- BEGIN PAGE BREADCRUMB -->

                    <ul class="page-breadcrumb breadcrumb">

                        <li>

                            <a href="product.php">Products</a>

                            <i class="fa fa-circle"></i>

                        </li>

                        <li>

                            <span class="active">View Vendor</span>

                        </li>

                    </ul>

                    <!-- END PAGE BREADCRUMB -->

                    <!-- BEGIN PAGE BASE CONTENT -->

                    

                    <div class="row">

                    	<div class="col-sm-12">

                        	<div class="portlet box blue ">

                                <div class="portlet-title">

                                    <div class="caption">

                                        <i class="fa fa-gift"></i>View Product
                                    </div>

                                   
                                </div>

                                <div class="portlet-body form">

                                   <?php

									//echo $sql;

										if(isset($_SESSION['msg']) && $_SESSION['msg']!='' ){

										?>

										<div class="alert alert-success display-hide" style="display:block">

											<button class="close" data-close="alert"></button>

											<span><?php echo $_SESSION['msg']; $_SESSION['msg']="";?> </span>

										</div>

										

									<?php

										$_SESSION['msg']='';

										}else if(isset($_SESSION['err']) and $_SESSION['err']!='' ){

										?>

										<div class="alert alert-danger  display-hide" style="display:block">

											<button class="close" data-close="alert"></button>

											<span><?php echo $_SESSION['err']; $_SESSION['err']="";?> </span>

										</div>

										

									<?php

										$_SESSION['err']='';

										}

									?>

                                    <form class="form-horizontal"  role="form" action="" enctype="multipart/form-data">

                                        <div class="form-body">
										
										<div class="row">
                                            	<div class="col-sm-6">
                                                <div class="form-group">
												
												<div class="form-group">

                                                
                                                
                                              <label class="col-sm-4 control-label">Picture:</label>
                                              <div class="col-sm-8" style="text-align:center;" >
                                              	<div id="my_camera">
                                                	<?php 
														if($c['file']!='' ){
															$photo=$c['file'];
															echo '<img src="'.$photo.'"/>';
														}else{
															echo '<img src="img/noimage.png"/>';
															$photo='';
														}
													?>
                                                	
                                                </div>
                                        		
                                               </div>
                                               

                                            </div>

                                                		<label class="col-sm-4 control-label">Product Code :</label>
                                                		<div class="col-sm-8">
														<input class="form-control" disabled="disabled" name="p_code" value="<?php echo $c['p_code']?>" type="text">
                                              			
                                                        </div>
                                            		</div>
                                                	<div class="form-group">

                                                		<label class="col-sm-4 control-label"> Name :</label>
                                                		<div class="col-sm-8">

                                              			<input class="form-control" disabled="disabled" name="name" value="<?php echo $c['name']?>" type="text"> 
                                                        </div>
                                            		</div>
											
                                                    <div class="form-group">
        
                                                        <label class="col-sm-4 control-label"> Detail:</label>
                                                        <div class="col-sm-8">
        
                                                      <input class="form-control" disabled="disabled" name="detail" value="<?php echo $c['detail']?>" type="text"> </div>
        
                                                    </div>
											
											
                                                    <div class="form-group">
        
                                                        <label class="col-sm-4 control-label">ID Category:</label>
                                                        <div class="col-sm-8">
														<select name="id_category" disabled="disabled"  class="form-control" >
                                                                <option value="<?php echo $c['id_category']?>"><?php echo $c['id_category']?></option>
    <?php
                                                                $category=mysqli_query($con,"select * from product_categories ORDER BY name ASC");
                                                                while($p=mysqli_fetch_array($category)){
                                                                    ?>
                                                                    <option value="<?php echo $p['name']?>"><?php echo $p['name']?></option>
                                                                  <?php 
                                                                }
                                                                ?>
															</select>
														
														
        
                                                       </div>
        
                                                    </div>

										

                                                    <div class="form-group">
        
                                                        <label class="col-sm-4 control-label"> Tax Type :</label>
        
                                                        <div class="col-sm-8">
														<select name="tax_type" disabled="disabled" class="form-control" >
                                                                <option value="<?php echo $c['tax_type']?>"><?php echo $c['tax_type']?></option>
    <?php
                                                                $tax=mysqli_query($con,"select * from tax ORDER BY title ASC");
                                                                while($r=mysqli_fetch_array($tax)){
                                                                    ?>
                                                                    <option value="<?php echo $r['title']?>"><?php echo $r['title']?></option>
                                                                  <?php 
                                                                }
                                                                ?>
															</select>
														
         
                                                            
                                                         </div>
        
                                                    </div>

                                      
                                                    <div class="form-group">
        
                                                        <label class="col-sm-4 control-label">Status :</label>
        
                                                        <div class="col-sm-8">
														<select name="status" disabled="disabled" class="form-control">
														<option value="Active">Active</option>
														<option value="InActive">InActive</option>
														</select>
        
                                                             
                                                       	</div>
        
                                                    </div>

                                                 
													
													<div class="form-group">
    
                                                        <label class="col-sm-4 control-label">ID Vendor :</label>
        
                                                        <div class="col-sm-8">
														
														<select name="id_vendor" disabled="disabled" class="form-control" >
                                                                <option value="<?php echo $c['id_vendor']?>"><?php echo $c['id_vendor']?></option>
    <?php
                                                                $vendor=mysqli_query($con,"select * from vendors ORDER BY vindor_id ASC");
                                                                while($v=mysqli_fetch_array($vendor)){
                                                                    ?>
                                                                    <option value="<?php echo $v['vindor_id']?>"><?php echo $v['vindor_id']?></option>
                                                                  <?php 
                                                                }
                                                                ?>
															</select>
														
        
                                                             
                                                       	</div>
        
                                                    </div>
													
													<div class="form-group">
    
                                                        <label class="col-sm-4 control-label">Purchase Price:</label>
        
                                                        <div class="col-sm-8">
        
                                                            <input  class="form-control" disabled="disabled" name="purchase_price" value="<?php echo $c['purchase_price']?>" type="number"> 
                                                       	</div>
        
                                                    </div>
													
													
													<div class="form-group">
    
                                                        <label class="col-sm-4 control-label">Sale Price:</label>
        
                                                        <div class="col-sm-8">
        
                                                            <input  class="form-control" disabled="disabled" name="sale_price"  value="<?php echo $c['sale_price']?>" type="number"> 
                                                       	</div>
        
                                                    </div>
													
													<div class="form-group">
    
                                                        <label class="col-sm-4 control-label"> Sale Price Dealer:</label>
        
                                                        <div class="col-sm-8">
        
                                                            <input  class="form-control" disabled="disabled" name="sale_dealer_price" value="<?php echo $c['sale_dealer_price']?>" type="number"> 
                                                       	</div>
        
                                                    </div>
													
													
													
													
										</div>
										
                                                
										</div>
                                        </div>
                                        

                                    </form>

									

                                </div>

                            </div>

                        

                        </div>

                    </div>

                    

                    
                 

                    

                    <!-- END PAGE BASE CONTENT -->

                </div>

                <!-- END CONTENT BODY -->

            </div>

            <!-- END CONTENT -->

            <!-- BEGIN QUICK SIDEBAR -->

            

            

            <!-- END QUICK SIDEBAR -->

        </div>

        <!-- END CONTAINER -->

        <!-- BEGIN FOOTER -->

        <?php include('footer.php'); ?>

        

        <!-- END FOOTER -->

        <!-- BEGIN QUICK NAV -->

       
        
        <!-- END QUICK NAV -->

        <!--[if lt IE 9]>

<script src="../assets/global/plugins/respond.min.js"></script>

<script src="../assets/global/plugins/excanvas.min.js"></script> 

<script src="../assets/global/plugins/ie8.fix.min.js"></script> 

<![endif]-->

        <!-- BEGIN CORE PLUGINS -->

        <?php include('core_plugins.php'); ?>

        <script src="../../../../assets/global/plugins/bootstrap-fileinput/bootstrap-fileinput.js" type="text/javascript"></script>

        <script src="../../../../assets/global/plugins/bootstrap-datetimepicker/js/bootstrap-datetimepicker.min.js" type="text/javascript"></script>

        <script src="../../../../assets/pages/scripts/components-date-time-pickers.min.js" type="text/javascript"></script>

        <script type="text/javascript">

    		$(".date-picker").datetimepicker({format: 'yyyy-mm-dd hh:ii'});

		</script>
	
	<!-- Configure a few settings and attach camera -->

    </body>



</html>