
function team() {

	this.Items = [];
  
	this.addItem = function(item) {
		//alert(item);
		this.Items.push(item);
		this.renderCart();
	}
	
	this.removeItem = function(item_number) {
		for(var i = this.Items.length - 1; i >= 0; i--) {
			if(this.Items[i].uid == item_number) {
				this.Items.splice(i, 1);
				this.renderCart();
				return true;
			}
		}
		return false;
	}


	this.renderCart = function(){
		var html = '';
		//console.log(this.Items.length);
  		for (var i = 0; i < this.Items.length; i++){ 

   			html += this.templateItem(this.Items[i]);
 		}
 
		
		$('#job_item_list').html(html);


		//this.afterAdditionJob(employees);
	}
	
	/*this.getSelectedItem = function(employee,number){
  		if(employee != 0){
    		return '<select name="select_item_'+number+'" class="select-2-basic inline-select labour_tech_selected disabled" data-width="80%" >'+
    		'<option value="'+employee.id+'" selected="selected">'+employee.name+'</option>'+
    		'</select>';
  		}else{
   			return '<select name="select_item_'+number+'" class="select-2-basic inline-select labour_tech_unselected" data-width="80%" required></select>';
 		}
	}*/
	
	this.templateItem = function(item){
  		html = '<li class="labout_list_item" data-uid="'+item.uid+'">'+
  			'<input type="hidden" name="products_uids[]" value="'+item.uid+'" >'+
			'<input type="hidden" name="products_ids[]" value="'+item.e_id+'" >'+
  			'<div class="row">'+
  				'<div class="col-md-1">'+
  					'<h4 class="left"><a href="#" class="deleteProduct"><i class="fa fa-trash"></i></a></h4>'+
  
  				'</div>'+
    			/*'<div class="col-md-3">'+
					this.getSelectedItem(item.employee,item.uid)+
  				'</div>'+*/
  				

				'<div class="col-md-3">'+
  					'<input type="text"  name="employee_name[]" class="form-control small-input p_rate" value="'+item.e_name+'">'+
  				'</div>'+
				
  				'<div class="col-md-3">'+
  					'<input type="text"  name="employee_email[]" class="form-control small-input p_rate" value="'+item.e_email+'">'+
  				'</div>'+
    			'<div class="col-md-3">'+
					'<input type="text"  name="employee_phone[]" class="form-control small-input p_qty" value="'+item.e_phone+'">'+
  				'</div>'+
				'<div class="col-md-2">'+
					'<input type="text"  name="employee_role[]" class="form-control small-input p_qty" value="'+item.e_type+'">'+
  				'</div>'+

  			'</div></li>';
  		//console.log(html);
  		return html;

	};
//////////expense tab date


	/*this.changeProp = function(uid,property,value,render = true){
	
  		for(var i = this.Items.length - 1; i >= 0; i--) {
    		if(this.Items[i].uid == uid) {
				//alert(JSON.stringify(value));
				if(property=="employee"){
					this.Items[i][property] = value;
					this.Items[i]['e_id'] = value['id'];
					this.Items[i]['e_name'] = value['name'];
					this.Items[i]['e_email'] = value['email'];
					this.Items[i]['e_phone'] = value['phone'];
					this.Items[i]['emp_id'] = value['emp_id'];
				}else{
					this.Items[i][property] = value;
				}
     
     			if(render)
     			{
      				this.renderCart();
    			}
  			}
		}

		return false;
	}*/




	/*this.afterAdditionJob = function(employees){
  		$('.select-2-basic').select2();
  		$('.datepicker').datepicker({
        	format: 'yyyy-mm-dd'
      	});
  		for(var k in employees) {
	  		var str='<option value="'+employees[k].id+'_'+employees[k].phone+'_'+employees[k].designation+'">'+employees[k].name+'/'+employees[k].emp_id+'</option>';
	  		$('.labour_tech_unselected').append(str);
  		}
	}*/

}

/************************* OUR JOB CART ****************************/
teamcart = new team();


$(document).ready(function(){

	/*$('body').on('click','.addLaborToJob',function(e){

    	e.preventDefault();

    	var item = {
      		uid : Math.round(Date.now() + Math.random()),
	  		e_id:0,
			emp_id:'',
	  		e_name:'',
	  		e_email:'',
	  		e_phone:'',
			e_type:'',
	  		employee:0,

    	};
    	teamcart.addItem(item);
  	});*/

 
	/*$('body').on("change",'.labour_tech_unselected',function(e){
  		var element = $(e.target);
  		var full_val = element.val();
  		var val_arr = full_val.split("_");
  		var id=val_arr[0];
 		var phone=val_arr[1];
		var email=val_arr[2];
  		var full_name = $(element).find('option:selected').text();
  		var name_arr = full_name.split("/");
		var name = name_arr[0];
  		var emp_id = name_arr[1];
  		var uid = element.closest('li').attr('data-uid');

  		var employee = {id: id, name:name, email: email, phone:phone, emp_id:emp_id};
  		element.attr('disabled', 'disabled');
  		element.removeClass('labour_tech_unselected');
  		element.addClass('labour_tech_selected');
  		teamcart.changeProp(uid,'employee',employee);

	});*/


/*	$('body').on('change','.e_email',function(e){
  		element = $(e.target);
  		var parentLI = $(element).closest('li');
  		var uid = parentLI.attr('data-uid');
  		var val = $(element).val();
  		val = val.trim();
  		if(typeof(val) == "NAN"){
   			return;
 		}
 		teamcart.changeProp(uid,'e_mail',val);
	});

	$('body').on('change','.e_name',function(e){
  		element = $(e.target);
  		var parentLI = $(element).closest('li');
  		var uid = parentLI.attr('data-uid');
  		var val = $(element).val();
  		val = val.trim();
  		if(typeof(val) == "NAN"){
   			return;
 		}
 		teamcart.changeProp(uid,'e_name',val);
	});

	$('body').on('change','.e_phone',function(e){
  		element = $(e.target);
  		var parentLI = $(element).closest('li');
  		var uid = parentLI.attr('data-uid');
  		var val = $(element).val();
  		val = val.trim();
  		if(typeof(val) == "NAN"){
   			return;
 		}
 		teamcart.changeProp(uid,'e_phone',val);
	});
	
	$('body').on('change','.e_type',function(e){
  		element = $(e.target);
  		var parentLI = $(element).closest('li');
  		var uid = parentLI.attr('data-uid');
  		var val = $(element).val();
  		val = val.trim();
  		if(typeof(val) == "NAN"){
   			return;
 		}
 		teamcart.changeProp(uid,'e_type',val);
	});
	*/
	$('body').on('click','.deleteProduct',function(e){
  		e.preventDefault();
  		element = $(e.target);
  		var parentLI = $(element).closest('li');
  		var uid = parentLI.attr('data-uid');
  		teamcart.removeItem(uid);
	});
	
	
	$('body').on('change','.tech_unselected',function(e){
		element = $(e.currentTarget).find("option:selected");
    	var id = element.val();
		if(id!=""){
			var data = {id: id };
		  	url = "ajax/load_employees.php";
		  	$.get(url, data,function(data) {
				var rs=JSON.parse(data);
				//alert(JSON.stringify(rs["employees"]));
				var employee=rs["employees"];
				
				
				//e.preventDefault();

				var item = {
					uid : Math.round(Date.now() + Math.random()),
					e_id:employee.id,
					emp_id:employee.emp_id,
					e_name:employee.name,
					e_email:employee.email,
					e_phone:employee.phone,
					e_type:employee.designation,
		
				};
    			teamcart.addItem(item);
		  	});
		}
	});




	

});




var employees=[];




$(document).ready(function(){
	 var data = {};
	 url = "ajax/load_employees.php";
	 $.get(url, data,function(data) {
		 var rs=JSON.parse(data);
		 if(rs["Success"]==1){
			employees=rs["employees"];
			for(var k in employees) {
				
	  		var str='<option value="'+employees[k].id+'">'+employees[k].name+'('+employees[k].designation+')</option>';
	  		$('.tech_unselected').append(str);
  		}
		 }
	
	});
	$('.select-2-basic').select2();

});



//////////////////////////////////////////////////// equipment resource code start   ///////////////////////////////




function equipment() {

	this.Items = [];
  
	this.addItem = function(item) {
		//alert(item);
		this.Items.push(item);
		this.renderCart();
	}
	
	this.removeItem = function(item_number) {
		for(var i = this.Items.length - 1; i >= 0; i--) {
			if(this.Items[i].uid == item_number) {
				this.Items.splice(i, 1);
				this.renderCart();
				return true;
			}
		}
		return false;
	}


	this.renderCart = function(){
		var html = '';
		//console.log(this.Items.length);
  		for (var i = 0; i < this.Items.length; i++){ 

   			html += this.templateItem(this.Items[i]);
 		}
 
		
		$('#job_item_list').html(html);


		//this.afterAdditionJob(employees);
	}
	
	/*this.getSelectedItem = function(employee,number){
  		if(employee != 0){
    		return '<select name="select_item_'+number+'" class="select-2-basic inline-select labour_tech_selected disabled" data-width="80%" >'+
    		'<option value="'+employee.id+'" selected="selected">'+employee.name+'</option>'+
    		'</select>';
  		}else{
   			return '<select name="select_item_'+number+'" class="select-2-basic inline-select labour_tech_unselected" data-width="80%" required></select>';
 		}
	}*/
	
	this.templateItem = function(item){
  		html = '<li class="labout_list_item" data-uid="'+item.uid+'">'+
  			'<input type="hidden" name="products_uids[]" value="'+item.uid+'" >'+
			'<input type="hidden" name="products_ids[]" value="'+item.e_id+'" >'+
  			'<div class="row">'+
  				'<div class="col-md-1">'+
  					'<h4 class="left"><a href="#" class="deleteProduct"><i class="fa fa-trash"></i></a></h4>'+
  
  				'</div>'+
    			/*'<div class="col-md-3">'+
					this.getSelectedItem(item.employee,item.uid)+
  				'</div>'+*/
  				

				'<div class="col-md-3">'+
  					'<input type="text"  name="employee_name[]" class="form-control small-input p_rate" value="'+item.e_name+'">'+
  				'</div>'+
				
  				'<div class="col-md-3">'+
  					'<input type="text"  name="employee_email[]" class="form-control small-input p_rate" value="'+item.e_email+'">'+
  				'</div>'+
    			'<div class="col-md-3">'+
					'<input type="text"  name="employee_phone[]" class="form-control small-input p_qty" value="'+item.e_phone+'">'+
  				'</div>'+
				'<div class="col-md-2">'+
					'<input type="text"  name="employee_role[]" class="form-control small-input p_qty" value="'+item.e_type+'">'+
  				'</div>'+

  			'</div></li>';
  		//console.log(html);
  		return html;

	};
//////////expense tab date


	/*this.changeProp = function(uid,property,value,render = true){
	
  		for(var i = this.Items.length - 1; i >= 0; i--) {
    		if(this.Items[i].uid == uid) {
				//alert(JSON.stringify(value));
				if(property=="employee"){
					this.Items[i][property] = value;
					this.Items[i]['e_id'] = value['id'];
					this.Items[i]['e_name'] = value['name'];
					this.Items[i]['e_email'] = value['email'];
					this.Items[i]['e_phone'] = value['phone'];
					this.Items[i]['emp_id'] = value['emp_id'];
				}else{
					this.Items[i][property] = value;
				}
     
     			if(render)
     			{
      				this.renderCart();
    			}
  			}
		}

		return false;
	}*/




	/*this.afterAdditionJob = function(employees){
  		$('.select-2-basic').select2();
  		$('.datepicker').datepicker({
        	format: 'yyyy-mm-dd'
      	});
  		for(var k in employees) {
	  		var str='<option value="'+employees[k].id+'_'+employees[k].phone+'_'+employees[k].designation+'">'+employees[k].name+'/'+employees[k].emp_id+'</option>';
	  		$('.labour_tech_unselected').append(str);
  		}
	}*/

}

/************************* OUR JOB CART ****************************/
equip_cart = new equipment();


$(document).ready(function(){

	/*$('body').on('click','.addLaborToJob',function(e){

    	e.preventDefault();

    	var item = {
      		uid : Math.round(Date.now() + Math.random()),
	  		e_id:0,
			emp_id:'',
	  		e_name:'',
	  		e_email:'',
	  		e_phone:'',
			e_type:'',
	  		employee:0,

    	};
    	equip_cart.addItem(item);
  	});*/

 
	/*$('body').on("change",'.labour_tech_unselected',function(e){
  		var element = $(e.target);
  		var full_val = element.val();
  		var val_arr = full_val.split("_");
  		var id=val_arr[0];
 		var phone=val_arr[1];
		var email=val_arr[2];
  		var full_name = $(element).find('option:selected').text();
  		var name_arr = full_name.split("/");
		var name = name_arr[0];
  		var emp_id = name_arr[1];
  		var uid = element.closest('li').attr('data-uid');

  		var employee = {id: id, name:name, email: email, phone:phone, emp_id:emp_id};
  		element.attr('disabled', 'disabled');
  		element.removeClass('labour_tech_unselected');
  		element.addClass('labour_tech_selected');
  		equip_cart.changeProp(uid,'employee',employee);

	});*/


/*	$('body').on('change','.e_email',function(e){
  		element = $(e.target);
  		var parentLI = $(element).closest('li');
  		var uid = parentLI.attr('data-uid');
  		var val = $(element).val();
  		val = val.trim();
  		if(typeof(val) == "NAN"){
   			return;
 		}
 		equip_cart.changeProp(uid,'e_mail',val);
	});

	$('body').on('change','.e_name',function(e){
  		element = $(e.target);
  		var parentLI = $(element).closest('li');
  		var uid = parentLI.attr('data-uid');
  		var val = $(element).val();
  		val = val.trim();
  		if(typeof(val) == "NAN"){
   			return;
 		}
 		equip_cart.changeProp(uid,'e_name',val);
	});

	$('body').on('change','.e_phone',function(e){
  		element = $(e.target);
  		var parentLI = $(element).closest('li');
  		var uid = parentLI.attr('data-uid');
  		var val = $(element).val();
  		val = val.trim();
  		if(typeof(val) == "NAN"){
   			return;
 		}
 		equip_cart.changeProp(uid,'e_phone',val);
	});
	
	$('body').on('change','.e_type',function(e){
  		element = $(e.target);
  		var parentLI = $(element).closest('li');
  		var uid = parentLI.attr('data-uid');
  		var val = $(element).val();
  		val = val.trim();
  		if(typeof(val) == "NAN"){
   			return;
 		}
 		equip_cart.changeProp(uid,'e_type',val);
	});
	*/
	$('body').on('click','.deleteProduct',function(e){
  		e.preventDefault();
  		element = $(e.target);
  		var parentLI = $(element).closest('li');
  		var uid = parentLI.attr('data-uid');
  		equip_cart.removeItem(uid);
	});
	
	
	$('body').on('change','.tech_unselected',function(e){
		element = $(e.currentTarget).find("option:selected");
    	var id = element.val();
		if(id!=""){
			var data = {id: id };
		  	url = "ajax/load_employees.php";
		  	$.get(url, data,function(data) {
				var rs=JSON.parse(data);
				//alert(JSON.stringify(rs["employees"]));
				var employee=rs["employees"];
				
				
				//e.preventDefault();

				var item = {
					uid : Math.round(Date.now() + Math.random()),
					e_id:employee.id,
					emp_id:employee.emp_id,
					e_name:employee.name,
					e_email:employee.email,
					e_phone:employee.phone,
					e_type:employee.designation,
		
				};
    			equip_cart.addItem(item);
		  	});
		}
	});




	

});




var employees=[];




$(document).ready(function(){
	 var data = {};
	 url = "ajax/load_employees.php";
	 $.get(url, data,function(data) {
		 var rs=JSON.parse(data);
		 if(rs["Success"]==1){
			employees=rs["employees"];
			for(var k in employees) {
				
	  		var str='<option value="'+employees[k].id+'">'+employees[k].name+'('+employees[k].designation+')</option>';
	  		$('.tech_unselected').append(str);
  		}
		 }
	
	});
	$('.select-2-basic').select2();

});

/*function getEmployee(id){

  var data = {pid: id };
  url = "http://"+ajax_url + "/json/getProductForCart";
  $.get(url, data,function(data) {
    equip_cart.addItem(JSON.parse(data));
  });
}
*/

