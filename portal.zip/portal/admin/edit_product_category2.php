<?php
//$con = mysqli_connect("localhost","root","","cantt_entry");
include("chksession.php");

include("Common.php");
//$tt=date("Ymdhis");
//$name=$_POST['name'];
			
			
			$result= mysqli_query($con,"update  product_categories set name='".mysqli_real_escape_string($con,$_POST['name'])."' where id=".$_GET['id']);
			
			

			$_SESSION['msg']="product categories has been Updated.";


			mysqli_close($con);		

	header('location:product_categories.php');
//echo $name;


?>