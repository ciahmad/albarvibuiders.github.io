<?php 
include("Common.php");
		$type=$_GET['type'];
		$cnic=$_GET['cnic'];
		$cnic2=str_replace("-","",$cnic);
		
		$sub_array=array("id"=>0);
		$black_list=0;
		
		$check_ncb=mysqli_query($con,"select * from `mp_ncb` where cnic='".$cnic."' or cnic='".$cnic2."'");
		if(mysqli_num_rows($check_ncb) > 0){
			$black_list=1;
		}
		
		$check_firm=mysqli_query($con,"select * from `mp_firm` where cnic='".$cnic."' or cnic='".$cnic2."'");
		if(mysqli_num_rows($check_firm) > 0){
			$black_list=1;
		}
		
		if($type=='visitor'){
			$visitor=mysqli_query($con,"select * from `mp_visitor` where cnic_no='".$cnic."' or cnic_no='".$cnic2."' ORDER BY id DESC LIMIT 1");
			if(mysqli_num_rows($visitor) > 0){
				$res=mysqli_fetch_array($visitor);

				$sub_array=array("id"=>$res['id'],"card_no"=>$res['card_no'],"cnic_no"=>$res['cnic_no'],"name"=>$res['name'],"house_no"=>$res['house_no'],"street"=>$res['street'],"complete_add"=>$res['complet_address'],"tehsil"=>$res['tehsil'],"district"=>$res['district'],"province"=>$res['province'],"mob_no"=>$res['mob_no'],"veh_reg_no"=>$res['vehi_reg_no'],"make"=>$res['make'],"gender"=>$res['gender'],"children"=>$res['children'],"proceed_to"=>$res['procees_to'],"purpose"=>$res['purpose'],"sponsor"=>$res['sponsor'],"svas_obsn"=>$res['svas_obsn'],"tim_in_auto"=>$res['tim_in_auto'],"hour"=>$res['hour'],"validity"=>$res['validity'],"time_out"=>$res['time_out'],"photo"=>$res['file']);

			}
		}
		
		if($type=='labour'){
			$labour=mysqli_query($con,"select * from `mp_labour` where cnic='".$cnic."' or cnic='".$cnic2."' ORDER BY id DESC LIMIT 1");
			if(mysqli_num_rows($labour) > 0){
				$res=mysqli_fetch_array($labour);

				$sub_array=array("id"=>$res['id'],"card_no"=>$res['card_no'],"cnic_no"=>$res['cnic'],"name"=>$res['name'],"house_no"=>$res['house_no'],"street"=>$res['street'],"complete_add"=>$res['complete_add'],"tehsil"=>$res['tehsil'],"district"=>$res['district'],"province"=>$res['province'],"mob_no"=>$res['mob_no'],"veh_reg_no"=>$res['veh_reg_no'],"make"=>$res['make'],"contractor_name"=>$res['constract_name'],"police_verification"=>$res['police_verification'],"verified_by"=>$res['verified_by'],"spec_permission"=>$res['spec_permission'],"sponsor"=>$res['sponsor'],"proceed_to"=>$res['proceed_to'],"svas_obsn"=>$res['svas_obns'],"time_in"=>$res['time_in'],"photo"=>$res['file']);

			}
		}
		
		$main_array=array("Black_list"=>$black_list, "data"=>$sub_array);
		//$check=mysqli_query($con,"select * from `mp_ncb` where cnic='".$cnic."'");
		
		
echo json_encode($main_array);
	//echo $black_list;
?>