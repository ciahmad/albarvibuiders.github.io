<?php
include("chksession.php");

include("Common.php");

			$sql="insert into qoutations set id_project='".mysqli_real_escape_string($con,$_GET['project_id'])."',project_title='".mysqli_real_escape_string($con,$_POST['title'])."',project_company='".mysqli_real_escape_string($con,$_POST['company'])."',project_customer='".mysqli_real_escape_string($con,$_POST['customer_name'])."',project_location='".mysqli_real_escape_string($con,$_POST['location'])."',total_qty=".sizeof($_POST["product"]).",total_price='".mysqli_real_escape_string($con,$_POST['total_price'])."',create_dt=now(),create_by='".mysqli_real_escape_string($con,$_SESSION['login_id'])."'";
			
			$result= mysqli_query($con,$sql);
			$qoutation_id=mysqli_insert_id($con);
			//exit;
			//echo $sql;
			//exit;product_dsc
			for($i=0; $i < sizeof($_POST["product"]); $i++){
				$q="insert into qoutation_items set id_qoutation=".$qoutation_id.",product_name='".mysqli_real_escape_string($con,$_POST['product'][$i])."',product_dsc='".mysqli_real_escape_string($con,$_POST['dsc'][$i])."',product_qty='".mysqli_real_escape_string($con,$_POST['qty'][$i])."',product_rate='".mysqli_real_escape_string($con,$_POST['rate'][$i])."',product_price='".mysqli_real_escape_string($con,$_POST['price'][$i])."'"; 
			$result2= mysqli_query($con,$q);
			//echo $q;
			}
			
			

			$_SESSION['msg']="Qoutation has been created.";


			mysqli_close($con);		

	header('location:project_qoutations.php?id='.$_GET['project_id']);



?>