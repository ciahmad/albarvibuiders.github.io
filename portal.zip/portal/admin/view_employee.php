<?php 

include("chksession.php");

include("Common.php");

include('header.php');
$employee=mysqli_query($con,"select * from employees where id='".mysqli_real_escape_string($con,$_GET['id'])."'");

$e=mysqli_fetch_array($employee);

 ?>

        <!-- BEGIN CONTAINER -->

        <div class="page-container">

            <!-- BEGIN SIDEBAR -->

            <?php include('left_sidebar.php'); ?>

            <!-- END SIDEBAR -->

            <!-- BEGIN CONTENT -->

            <div class="page-content-wrapper">

                <!-- BEGIN CONTENT BODY -->

                <div class="page-content">

                    <!-- BEGIN PAGE HEAD-->

                    <div class="page-head">

                        <!-- BEGIN PAGE TITLE -->

                        <div class="page-title">

                            <h1>Employees Management

                                <small>View Employee</small>

                            </h1>

                        </div>

                        <!-- END PAGE TITLE -->

                        <!-- BEGIN PAGE TOOLBAR -->

                        

                        <!-- END PAGE TOOLBAR -->

                    </div>

                    <!-- END PAGE HEAD-->

                    <!-- BEGIN PAGE BREADCRUMB -->

                    <ul class="page-breadcrumb breadcrumb">

                        <li>

                            <a href="employees.php">Employees</a>

                            <i class="fa fa-circle"></i>

                        </li>

                        <li>

                            <span class="active">View Employee</span>

                        </li>

                    </ul>

                    <!-- END PAGE BREADCRUMB -->

                    <!-- BEGIN PAGE BASE CONTENT -->

                    

                    <div class="row">

                    	<div class="col-sm-12">

                        	<div class="portlet box blue ">

                                <div class="portlet-title">

                                    <div class="caption">

                                        <i class="fa fa-gift"></i>View Employee
                                    </div>

                                   
                                </div>

                                <div class="portlet-body form">

                                   <?php

									//echo $sql;

										if(isset($_SESSION['msg']) && $_SESSION['msg']!='' ){

										?>

										<div class="alert alert-success display-hide" style="display:block">

											<button class="close" data-close="alert"></button>

											<span><?php echo $_SESSION['msg']; $_SESSION['msg']="";?> </span>

										</div>

										

									<?php

										$_SESSION['msg']='';

										}else if(isset($_SESSION['err']) and $_SESSION['err']!='' ){

										?>

										<div class="alert alert-danger  display-hide" style="display:block">

											<button class="close" data-close="alert"></button>

											<span><?php echo $_SESSION['err']; $_SESSION['err']="";?> </span>

										</div>

										

									<?php

										$_SESSION['err']='';

										}

									?>

                                    <form class="form-horizontal"  role="form" action="" enctype="multipart/form-data">

                                        <div class="form-body">
										
										<div class="row">
                                            	<div class="col-sm-6">
                                                <div class="form-group">

                                                		<label class="col-sm-4 control-label">Emp ID:</label>
                                                		<div class="col-sm-8">
														<input class="form-control" disabled="disabled" name="emp_id" value="<?php echo $e['emp_id']?>" type="text">
                                              			
                                                        </div>
                                            		</div>
                                                	<div class="form-group">

                                                		<label class="col-sm-4 control-label">Emp Name :</label>
                                                		<div class="col-sm-8">

                                              			<input class="form-control" disabled="disabled" name="name" value="<?php echo $e['name']?>" type="text"> 
                                                        </div>
                                            		</div>
											
                                                    <div class="form-group">
        
                                                        <label class="col-sm-4 control-label">Father Name:</label>
                                                        <div class="col-sm-8">
        
                                                      <input class="form-control" disabled="disabled" name="father_name" value="<?php echo $e['father_name']?>" type="text"> </div>
        
                                                    </div>
											
											
                                                    <div class="form-group">
        
                                                        <label class="col-sm-4 control-label">Emp CNIC:</label>
                                                        <div class="col-sm-8">
        
                                                      <input class="form-control" disabled="disabled" name="cnic" value="<?php echo $e['cnic']?>" type="text"> </div>
        
                                                    </div>

										

                                                    <div class="form-group">
        
                                                        <label class="col-sm-4 control-label">Emp Phone:</label>
        
                                                        <div class="col-sm-8">
        
                                                            <input name="phone" disabled="disabled" class="form-control" value="<?php echo $e['phone']?>" type="text"> 
                                                            
                                                         </div>
        
                                                    </div>

                                      
                                                    <div class="form-group">
        
                                                        <label class="col-sm-4 control-label">Emp DOB:</label>
        
                                                        <div class="col-sm-8">
        
                                                            <input name="dob" disabled="disabled" class="form-control" value="<?php echo $e['dob']?>" type="date"> 
                                                       	</div>
        
                                                    </div>

                                                    <div class="form-group">
    
                                                        <label class="col-sm-4 control-label">Emp Designation:</label>
        
                                                        <div class="col-sm-8">
        
                                                            <input name="designation" disabled="disabled" class="form-control" value="<?php echo $e['designation']?>" type="text"> 
                                                       	</div>
        
                                                    </div>
                                            
                                            		<div class="form-group">

                                                		<label class="col-sm-4 control-label">Address:</label>

                                                        <div class="col-sm-8">
        
                                                            <input name="address" disabled="disabled" class="form-control" value="<?php echo $e['address']?>" type="text"> 
                                                       	</div>
                                                   
                                                    </div>
											
											<div class="form-group">

                                                <label class="col-sm-4 control-label">E-Mail:</label>

                                                <div class="col-sm-8">

                                                    <input name="email" disabled="disabled" class="form-control" value="<?php echo $e['email']?>" type="text"> </div>
                                           
                                            </div>
                                            
                                            <div class="form-group">

                                                <label class="col-sm-4 control-label"> Salary:</label>

                                                <div class="col-sm-8">
													<input type="text" name="salary" disabled="disabled"  value="<?php echo $e['salary']?>" class="form-control"/>
                                                   
                                                  </div>

                                           </div>

										
										</div>
										
                                                <div class="col-sm-6">
                                                	<div class="form-group">

                                                
                                                
                                              <label class="col-sm-4 control-label">Picture:</label>
                                              <div class="col-sm-8" style="text-align:center;" >
                                              	<div id="my_camera">
                                                	<?php 
														if($e['file']!='' ){
															$photo=$e['file'];
															echo '<img src="'.$photo.'"/>';
														}else{
															echo '<img src="img/noimage.png"/>';
															$photo='';
														}
													?>
                                                	
                                                </div>
                                                
                                        		
                                               </div>
                                               

                                            </div>
											<div class="form-group">

                                         <label class="col-sm-4 control-label">Bouns:</label>

                                         <div class="col-sm-8">
													
										 <input type="text" name="bouns" disabled="disabled"  value="<?php echo $e['bouns']?>" class="form-control"/>
                                                   
                                                  </div>

                                            </div>
												
											<div class="form-group">

                                         <label class="col-sm-4 control-label">Medical Allowance:</label>

                                         <div class="col-sm-8">
													
										 <input type="text" disabled="disabled" name="medical_allowance"  value="<?php echo $e['medical_allowance']?>" class="form-control"/>
                                                   
                                                  </div>

                                            </div>
											
											<div class="form-group">

                                         <label class="col-sm-4 control-label">Allowed Leave:</label>

                                         <div class="col-sm-8">
													
													
													<input type="text" disabled="disabled" name="allowed_leave" class="form-control" value="<?php echo $e['allowed_leave']?>" />
										 
                                                   
                                                  </div>

                                            </div>
                                            		
												<div class="form-group">

                                         <label class="col-sm-4 control-label">Emergency Contact Person Name:</label>

                                         <div class="col-sm-8">
													
													
													<input type="text" disabled="disabled" name="emergency_contact_person_name" class="form-control" value="<?php echo $e['emergency_contact_person_name']?>"  />   
                                                  </div>

                                            </div>
											
											<div class="form-group">

                                         <label class="col-sm-4 control-label">Emergency Contact Person NO:</label>

                                         <div class="col-sm-8">
													
										 <input type="text" disabled="disabled" name="emergency_contact_person_no"  value="<?php echo $e['emergency_contact_person_no']?>" class="form-control"/>
                                                   
                                                  </div>

                                            </div>
											
											 </div>
										
                                            
										</div>
										<div class="form-group">

                                                		<label class="col-sm-8 control-label"><b><u>Employee Qualification</u></b></label>
                                                		
                                            		</div>
										
										
										<div id="" class="">

										

                                       

                                        	
                                            
                                            <table class="table table-striped table-bordered table-hover " >

                                        		<thead>

                                            		<tr role="row">

                                                    	

                                                        <th width="222" colspan="1" rowspan="1" class="sorting" style="width: 50px;" tabindex="0" aria-controls="sample_1_2" aria-label=" Email : activate to sort column ascending">ID:</th>
                                                        <th width="106" rowspan="1" class="sorting" style="width: 150px;" tabindex="0" aria-controls="sample_1_2" aria-label=" Status : activate to sort column ascending">Emp ID # </th>
                                                        <th width="104" rowspan="1" class="sorting" style="width: 150px;" tabindex="0" aria-controls="sample_1_2" aria-label=" Status : activate to sort column ascending">Degree Name</th>
                                                        <th width="104" rowspan="1" class="sorting" style="width: 200px;" tabindex="0" aria-controls="sample_1_2" aria-label=" Status : activate to sort column ascending">Board/Universty:</th>

                                                        <th width="104" colspan="1" rowspan="1" class="sorting" style="width:200px;" tabindex="0" aria-controls="sample_1_2" aria-label=" Status : activate to sort column ascending">Total Marks: </th>
                                                        <th width="115" rowspan="1" class="sorting" style="width: 225px;" tabindex="0" aria-controls="sample_1_2" aria-label=" Actions : activate to sort column ascending">Passed Year:</th>
                                                        
                                                        
                                                        
                                                        

                                                	</tr>

                                       			</thead>

                                        		

                                        		<tbody>

												<?php

		  

		  $employee=mysqli_query($con,"select * from employees_qualification where emp_id='".mysqli_real_escape_string($con,$e['emp_id'])."'");
		   
		  
  		  while($row=mysqli_fetch_array($employee)){

				

				

		   ?>

                                                    <tr class="gradeX odd" role="row">

                                                        <td>
                                                          <strong><?php echo $row['id']; ?></strong>
                                                          </td>
														  <td>
                                                          <strong><?php echo $row['emp_id']; ?></strong>
                                                          </td>
														  <td>
                                                          <strong><?php echo $row['degree_name']; ?></strong>
                                                          </td>
														  <td>
                                                          <strong><?php echo $row['board_uni']; ?></strong>
                                                          </td>
														  <td><strong><?php echo $row['total_marks']; ?></strong></td>
                                                          
														  
                                                          
                                                          
														 
														  
                                                       
                                                        <td>

                                                            

                                                        </td>

                                                    </tr>

													<?php

			

		   }

			?>

                                            </tbody>

                                    	</table>
										
										<div class="form-group">

                                                		<label class="col-sm-8 control-label"><b><u>Employee Experience</u></b></label>
                                                		
                                            		</div>
										
										
										<div id="" class="">

										

                                       

                                        	
                                            
                                            <table class="table table-striped table-bordered table-hover dataTable" >

                                        		<thead>

                                            		<tr role="row">

                                                    	

                                                        <th width="222" colspan="1" rowspan="1" class="sorting" style="width: 50px;" tabindex="0" aria-controls="sample_1_2" aria-label=" Email : activate to sort column ascending">ID:</th>
                                                        <th width="106" rowspan="1" class="sorting" style="width: 150px;" tabindex="0" aria-controls="sample_1_2" aria-label=" Status : activate to sort column ascending">Emp ID # </th>
                                                        <th width="104" rowspan="1" class="sorting" style="width: 150px;" tabindex="0" aria-controls="sample_1_2" aria-label=" Status : activate to sort column ascending">Designation</th>
                                                        <th width="104" rowspan="1" class="sorting" style="width: 200px;" tabindex="0" aria-controls="sample_1_2" aria-label=" Status : activate to sort column ascending">Country:</th>

                                                        <th width="104" colspan="1" rowspan="1" class="sorting" style="width:200px;" tabindex="0" aria-controls="sample_1_2" aria-label=" Status : activate to sort column ascending">Company Name: </th>
                                                        <th width="115" rowspan="1" class="sorting" style="width: 225px;" tabindex="0" aria-controls="sample_1_2" aria-label=" Actions : activate to sort column ascending">Total Experience:</th>
                                                        
                                                        

                                                	</tr>

                                       			</thead>

                                        		

                                        		<tbody>

												<?php

		  

		   		
											$experince=mysqli_query($con,"select * from employees_experience where emp_id='".mysqli_real_escape_string($con,$e['emp_id'])."'");
		   
		  
  		  while($exp=mysqli_fetch_array($experince)){

		
		   ?>

                                                    <tr class="gradeX odd" role="row">

                                                        <td>

                                                           <?php echo $exp['id'];?>
															
															

                                                        </td>
                                                        <td>
                                                          <strong><?php echo $exp['emp_id'];?></strong>
                                                          </td>
														  <td>
                                                          <strong><?php echo $exp['designation'];?></strong>
                                                          </td>
														  
														  <td>
                                                          <strong><?php echo $exp['country'];?></strong>
                                                          </td>
														  <td><strong><?php echo $exp['company_name'];?></strong></td>
														  <td><?php echo $exp['total_experience'];?></td>
														  
														  
                                                       
                                                        

                                                    </tr>

													<?php

			

		   }

			?>

                                            </tbody>

                                    	</table>
                                 	</div>

                                 	</div>	
                                        </div>
                                        

                                    </form>

									

                                </div>

                            </div>

                        

                        </div>

                    </div>

                    

                    

                    

                    

                    

                    

                    <!-- END PAGE BASE CONTENT -->

                </div>

                <!-- END CONTENT BODY -->

            </div>

            <!-- END CONTENT -->

            <!-- BEGIN QUICK SIDEBAR -->

            

            

            <!-- END QUICK SIDEBAR -->

        </div>

        <!-- END CONTAINER -->

        <!-- BEGIN FOOTER -->

        <?php include('footer.php'); ?>

        

        <!-- END FOOTER -->

        <!-- BEGIN QUICK NAV -->

       
        
        <!-- END QUICK NAV -->

        <!--[if lt IE 9]>

<script src="../assets/global/plugins/respond.min.js"></script>

<script src="../assets/global/plugins/excanvas.min.js"></script> 

<script src="../assets/global/plugins/ie8.fix.min.js"></script> 

<![endif]-->

        <!-- BEGIN CORE PLUGINS -->

        <?php include('core_plugins.php'); ?>

        <script src="../../../../assets/global/plugins/bootstrap-fileinput/bootstrap-fileinput.js" type="text/javascript"></script>

        <script src="../../../../assets/global/plugins/bootstrap-datetimepicker/js/bootstrap-datetimepicker.min.js" type="text/javascript"></script>

        <script src="../../../../assets/pages/scripts/components-date-time-pickers.min.js" type="text/javascript"></script>

        <script type="text/javascript">

    		$(".date-picker").datetimepicker({format: 'yyyy-mm-dd hh:ii'});

		</script>
	
	<!-- Configure a few settings and attach camera -->

    </body>



</html>