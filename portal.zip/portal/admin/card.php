<?php

include("chksession.php");

include("Common.php");

include("header.php");

					   	$sql="select * from  army where id='".$_GET['id']."'";

		   				$result=mysqli_query($con,$sql);
		   
  		  				$row=mysqli_fetch_array($result);

				

				

		   ?>
				


        <!-- BEGIN CONTAINER -->

        <div class="page-container">

            <!-- BEGIN SIDEBAR -->

            <?php include('left_sidebar.php'); ?>

            <!-- END SIDEBAR -->

            <!-- BEGIN CONTENT -->

            <div class="page-content-wrapper">

                <!-- BEGIN CONTENT BODY -->

                <div class="page-content" >

                    <!-- BEGIN PAGE HEAD-->

                    <div class="page-head">

                        <!-- BEGIN PAGE TITLE -->

                       

                        <!-- END PAGE TITLE -->

                        <!-- BEGIN PAGE TOOLBAR -->

                        

                        <!-- END PAGE TOOLBAR -->

                    </div>

                    <!-- END PAGE HEAD-->

                    <!-- BEGIN PAGE BREADCRUMB -->

                    

                    <!-- END PAGE BREADCRUMB -->

                    <!-- BEGIN PAGE BASE CONTENT -->

                    

                    <div class="row" >

                        <div class="col-md-12">

                            <!-- BEGIN EXAMPLE TABLE PORTLET-->

                            <div class="portlet light bordered">

                                

                                <div class="portlet-body" style="height:100%; text-align: center">
                                	<div id="confirm_pass" style="width:250px; margin:100px auto;">

                                            <div class="form-title">
                            
                                                <span class="form-title"><b>Please first Confirm your password.</b></span><br /><br />
                            
                                              
                            
                                            </div>
                            
                                            
                            
                                            <div class="alert alert-danger display-hide">
                            
                                                <button class="close" data-close="alert"></button>
                            
                                                <span> 
                            
                                                    Enter any username and password.
                            
                                                 </span>
                            
                                            </div>
                            
                                            
                            
                                            <div class="form-group">
                            
                                                <label class="control-label visible-ie8 visible-ie9">Password</label>
                            
                                                <input class="form-control form-control-solid placeholder-no-fix" type="password" autocomplete="off" placeholder="Password" id="password" /> </div>
                            
                                            <div class="form-actions">
                            
                                                <button type="button" class="btn green btn-block uppercase" onclick="confirm_password('<?php echo $_SESSION['password']; ?>')">Confirm</button>
                            
                                            </div>
                            
                                    </div>

                                    <div id="card">
                                        <table>
                                            <tr>
                                                <td width="21%"  valign="top" style="margin-top:"><img src="img/card-logo.png" width="50" height="50" /></td>
                                                <td width="57%"  class="card_heading" valign="top">ENTRY PASS 2018<BR />KOHAT CANTT</td>
                                                <td width="22%"  rowspan="2" valign="top"><img src="<?php echo $row['file'];?>" width="65" height="70" /></td>
                                            </tr>
                                            <tr>
                                                <td class="card_left">Card No</td>
                                                <td class="card_info"><?php echo $row['card_no'];?></td>
                                            </tr>
                                            <tr>
                                                <td class="card_left">Name</td>
                                                <td class="card_info"><?php echo $row['appl_name'];?></td>
                                                <td></td>
                                            </tr><tr>
                                                <td class="card_left">CNIC</td>
                                                <td class="card_info"><?php echo $row['cnic'];?></td>
                                                <td></td>
                                            </tr>
                                            <tr>
                                                <td class="card_left">Address</td>
                                                <td class="card_info"><?php echo $row['appl_present_address'];?></td>
                                                <td rowspan="3" align="right"><img src="img/stamp.png" width="50" height="50" /></td>
                                            </tr>
                                            <tr>
                                                <td class="card_left">Veh No</td>
                                                <td class="card_info"><?php echo $row['vehregn_no'];?></td>
                                            </tr>
                                            <tr>
                                                <td colspan="2" class="card_bottom"><span>SCHOOL VISITORS</span></td>
                                            </tr>
                                            
                                            
                                            
                                        </table>
                                        <br />
                                        <br />
                                        <br />
                                        <br />
                                        <div class="btn-group">

                                        	<button id="sample_editable_1_2_new" class="btn sbold green" onclick="card_print()" > Print Card

                                            	<i class="fa fa-print"></i>

                                        	</button>


                                    	</div>
                                                
                                </div>

                                </div>

                            </div>

                            <!-- END EXAMPLE TABLE PORTLET-->

                        </div>

                    </div>

                    

                    

                    

                    

                    

                    

                    <!-- END PAGE BASE CONTENT -->

                </div>

                <!-- END CONTENT BODY -->

            </div>

            <!-- END CONTENT -->

            <!-- BEGIN QUICK SIDEBAR -->

            

            

            <!-- END QUICK SIDEBAR -->

        </div>

        <!-- END CONTAINER -->

        <!-- BEGIN FOOTER -->

        <?php include('footer.php'); ?>

        

        <!-- END FOOTER -->

        <!-- BEGIN QUICK NAV -->

        <?php include('quick_nav.php'); ?>

        

        

        <!-- END QUICK NAV -->

        <!--[if lt IE 9]>

<script src="../assets/global/plugins/respond.min.js"></script>

<script src="../assets/global/plugins/excanvas.min.js"></script> 

<script src="../assets/global/plugins/ie8.fix.min.js"></script> 

<![endif]-->

        <!-- BEGIN CORE PLUGINS -->

        <?php include('core_plugins.php'); ?>

        

        <!-- END THEME LAYOUT SCRIPTS -->

		<script src="../assets/global/plugins/bootstrap-confirmation/bootstrap-confirmation.min.js" type="text/javascript"></script>

		<script src="../assets/pages/scripts/ui-confirmations.min.js" type="text/javascript"></script>

        <script>

            $(document).ready(function()

            {

                $('#clickmewow').click(function()

                {

                    $('#radio1003').attr('checked', 'checked');

                });

            })
			function confirm_password(pass){
				var cpass=$('#password').val();
				if (cpass==pass){
					$('#confirm_pass').hide();
					$('#card').show();
					//alert(1);
				}else{
					window.location="logout.php";
				}
			}
			
			function card_print() {
				window.print();
			}

        </script>

    </body>



</html>