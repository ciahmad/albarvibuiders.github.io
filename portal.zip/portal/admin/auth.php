<?php

@session_start(); 

@ob_start();

include("Common.php");



$loginid = mysqli_real_escape_string($con, $_POST['username']);

$pass = mysqli_real_escape_string($con, $_POST['password']);



$sql="select * from users where username='".$loginid."' and password='".$pass."'";



$rs=mysqli_query($con,$sql);



if(mysqli_num_rows($rs)>0){

	$row=mysqli_fetch_array($rs);

	$_SESSION['login_id']=$row['id'];

	$_SESSION['login_user']=$row['username'];

	$_SESSION['login_name']=$row['name'];
	
	$_SESSION['login_section']=$row['section'];

	$_SESSION['login_role']=$row['role'];

	$_SESSION['password']=$row['password'];

	$_SESSION['login_site']=$row['site'];

	header("location:welcome.php");

	//header("location:map_monitoring.php");

}else{

	$_SESSION['err']="Invalid Login ID/Password, Please try again.";

	header("location:index.php");

}

?>