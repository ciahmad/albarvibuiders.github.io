<?php
//$con = mysqli_connect("localhost","root","","company_data");
include("chksession.php");

include("Common.php");
//$tt=date("Ymdhis");

			$sql = "insert into users set name='".mysqli_real_escape_string($con,$_POST['name'])."',
			  username='".mysqli_real_escape_string($con,$_POST['username'])."', 
			  email='".mysqli_real_escape_string($con,$_POST['email'])."',
			  reg_date=now(),password='".mysqli_real_escape_string($con,$_POST['password'])."',
			  phone='".mysqli_real_escape_string($con,$_POST['phone'])."',
			  site='".mysqli_real_escape_string($con,$_POST['site'])."',
			  status='".mysqli_real_escape_string($con,$_POST['status'])."',Role='User'";
			  mysqli_query($con,$sql);

				$_SESSION['msg']="User has been created.";
				header('location:users.php');
				mysqli_close($con);		


?>