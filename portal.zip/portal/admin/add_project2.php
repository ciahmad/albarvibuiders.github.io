<?php
//$con = mysqli_connect("localhost","root","","cantt_entry");
include("chksession.php");

include("Common.php");

//echo $_SESSION['login_id'];
//exit;

			
			
			$result= mysqli_query($con, "insert into projects set title='".mysqli_real_escape_string($con,$_POST['title'])."',id_customer='".mysqli_real_escape_string($con,$_POST['id_customer'])."',status='New',location='".mysqli_real_escape_string($con,$_POST['location'])."',create_dt=now(),add_by='".mysqli_real_escape_string($con,$_SESSION['login_id'])."'");
			
			

			$_SESSION['msg']="Project has been created.";


			mysqli_close($con);		

	header('location:projects.php');



?>