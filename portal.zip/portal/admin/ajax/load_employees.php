<?php  include("../Common.php");

$main_array=array();

if(isset($_GET["id"])){
	$sql="SELECT id,emp_id,name,email, phone, designation from employees where id='".$_GET["id"]."' ORDER BY name ASC ";
	$products=mysqli_query($con,$sql);
	if(mysqli_num_rows($products)>0){
		$row=mysqli_fetch_array($products);
			
			$product_array=array("id"=>$row['id'],"emp_id"=>$row['emp_id'],"name"=>$row['name'],"email"=>$row['email'],"phone"=>$row['phone'],"designation"=>$row['designation']);
				//array_push($product_array,$sub_array);
		
		$main_array=array("Success"=>"1", "employees"=>$product_array);
	}else{
		$main_array=array("Success"=>"0");
	
	}
}else{
	
	$sql="SELECT id,emp_id,name,email, phone,designation from employees ORDER BY name ASC ";
	$products=mysqli_query($con,$sql);
	if(mysqli_num_rows($products)>0){
		$product_array=array();
		while($row=mysqli_fetch_array($products)){
			
			$sub_array=array("id"=>$row['id'],"name"=>$row['name'],"designation"=>$row['designation']);
				array_push($product_array,$sub_array);
		}
		$main_array=array("Success"=>"1", "employees"=>$product_array);
	}else{
		$main_array=array("Success"=>"0");
	
	}
}
echo json_encode($main_array);
 ?>