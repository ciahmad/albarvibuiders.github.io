<?php 

include("chksession.php");

include("Common.php");

include('header.php');
$vendor=mysqli_query($con,"select * from vendors where id='".mysqli_real_escape_string($con,$_GET['id'])."'");

$e=mysqli_fetch_array($vendor);

 ?>

        <!-- BEGIN CONTAINER -->

        <div class="page-container">

            <!-- BEGIN SIDEBAR -->

            <?php include('left_sidebar.php'); ?>

            <!-- END SIDEBAR -->

            <!-- BEGIN CONTENT -->

            <div class="page-content-wrapper">

                <!-- BEGIN CONTENT BODY -->

                <div class="page-content">

                    <!-- BEGIN PAGE HEAD-->

                    <div class="page-head">

                        <!-- BEGIN PAGE TITLE -->

                        <div class="page-title">

                            <h1>Vendors Management

                                <small>View Vendor</small>

                            </h1>

                        </div>

                        <!-- END PAGE TITLE -->

                        <!-- BEGIN PAGE TOOLBAR -->

                        

                        <!-- END PAGE TOOLBAR -->

                    </div>

                    <!-- END PAGE HEAD-->

                    <!-- BEGIN PAGE BREADCRUMB -->

                    <ul class="page-breadcrumb breadcrumb">

                        <li>

                            <a href="vendors.php">Vendors</a>

                            <i class="fa fa-circle"></i>

                        </li>

                        <li>

                            <span class="active">View Vendor</span>

                        </li>

                    </ul>

                    <!-- END PAGE BREADCRUMB -->

                    <!-- BEGIN PAGE BASE CONTENT -->

                    

                    <div class="row">

                    	<div class="col-sm-12">

                        	<div class="portlet box blue ">

                                <div class="portlet-title">

                                    <div class="caption">

                                        <i class="fa fa-gift"></i>View Vendor
                                    </div>

                                   
                                </div>

                                <div class="portlet-body form">

                                   <?php

									//echo $sql;

										if(isset($_SESSION['msg']) && $_SESSION['msg']!='' ){

										?>

										<div class="alert alert-success display-hide" style="display:block">

											<button class="close" data-close="alert"></button>

											<span><?php echo $_SESSION['msg']; $_SESSION['msg']="";?> </span>

										</div>

										

									<?php

										$_SESSION['msg']='';

										}else if(isset($_SESSION['err']) and $_SESSION['err']!='' ){

										?>

										<div class="alert alert-danger  display-hide" style="display:block">

											<button class="close" data-close="alert"></button>

											<span><?php echo $_SESSION['err']; $_SESSION['err']="";?> </span>

										</div>

										

									<?php

										$_SESSION['err']='';

										}

									?>

                                    <form class="form-horizontal"  role="form" action="" enctype="multipart/form-data">

                                        <div class="form-body">
										
										<div class="row">
                                            	<div class="col-sm-6">
                                                <div class="form-group">

                                                		<label class="col-sm-4 control-label"> ID:</label>
                                                		<div class="col-sm-8">
														<input class="form-control" disabled="disabled" name="vindor_id" value="<?php echo $e['vindor_id']?>" type="text">
                                              			
                                                        </div>
                                            		</div>
                                                	<div class="form-group">

                                                		<label class="col-sm-4 control-label"> Name :</label>
                                                		<div class="col-sm-8">

                                              			<input class="form-control" disabled="disabled" name="name" value="<?php echo $e['name']?>" type="text"> 
                                                        </div>
                                            		</div>
											
                                                    <div class="form-group">
        
                                                        <label class="col-sm-4 control-label">Father Name:</label>
                                                        <div class="col-sm-8">
        
                                                      <input class="form-control" disabled="disabled" name="fname" value="<?php echo $e['fname']?>" type="text"> </div>
        
                                                    </div>
											
											
                                                    <div class="form-group">
        
                                                        <label class="col-sm-4 control-label"> CNIC:</label>
                                                        <div class="col-sm-8">
        
                                                      <input class="form-control" disabled="disabled" name="cnic" value="<?php echo $e['cnic']?>" type="text"> </div>
        
                                                    </div>

										

                                                    <div class="form-group">
        
                                                        <label class="col-sm-4 control-label"> Phone:</label>
        
                                                        <div class="col-sm-8">
        
                                                            <input name="phone" disabled="disabled" class="form-control" value="<?php echo $e['phone']?>" type="text"> 
                                                            
                                                         </div>
        
                                                    </div>

                                      
                                                    <div class="form-group">
        
                                                        <label class="col-sm-4 control-label"> D-O-B:</label>
        
                                                        <div class="col-sm-8">
        
                                                            <input name="dob" disabled="disabled" class="form-control" value="<?php echo $e['dob']?>" type="date"> 
                                                       	</div>
        
                                                    </div>

                                                    <div class="form-group">
    
                                                        <label class="col-sm-4 control-label"> Designation:</label>
        
                                                        <div class="col-sm-8">
        
                                                            <input name="designation" class="form-control" disabled="disabled" value="<?php echo $e['designation']?>" type="text"> 
                                                       	</div>
        
                                                    </div>
                                            
                                            		<div class="form-group">

                                                		<label class="col-sm-4 control-label">Address:</label>

                                                        <div class="col-sm-8">
        
                                                            <input disabled="disabled" name="address" class="form-control" value="<?php echo $e['address']?>" type="text"> 
                                                       	</div>
                                                   
                                                    </div>
											
											<div class="form-group">

                                                <label class="col-sm-4 control-label">E-Mail:</label>

                                                <div class="col-sm-8">

                                                    <input disabled="disabled" name="email" class="form-control" value="<?php echo $e['email']?>" type="text"> </div>
                                           
                                            </div>
                                            
                                            <div class="form-group">

                                                <label class="col-sm-4 control-label">Company Name:</label>

                                                <div class="col-sm-8">

                                                    <input disabled="disabled" name="company" class="form-control" value="<?php echo $e['company']?>" type="text"> </div>
                                           
                                            </div>
                                            
                                            
										</div>
										
                                                
										</div>
                                        </div>
                                        

                                    </form>

									

                                </div>

                            </div>

                        

                        </div>

                    </div>

                    

                    
                 

                    

                    <!-- END PAGE BASE CONTENT -->

                </div>

                <!-- END CONTENT BODY -->

            </div>

            <!-- END CONTENT -->

            <!-- BEGIN QUICK SIDEBAR -->

            

            

            <!-- END QUICK SIDEBAR -->

        </div>

        <!-- END CONTAINER -->

        <!-- BEGIN FOOTER -->

        <?php include('footer.php'); ?>

        

        <!-- END FOOTER -->

        <!-- BEGIN QUICK NAV -->

       
        
        <!-- END QUICK NAV -->

        <!--[if lt IE 9]>

<script src="../assets/global/plugins/respond.min.js"></script>

<script src="../assets/global/plugins/excanvas.min.js"></script> 

<script src="../assets/global/plugins/ie8.fix.min.js"></script> 

<![endif]-->

        <!-- BEGIN CORE PLUGINS -->

        <?php include('core_plugins.php'); ?>

        <script src="../../../../assets/global/plugins/bootstrap-fileinput/bootstrap-fileinput.js" type="text/javascript"></script>

        <script src="../../../../assets/global/plugins/bootstrap-datetimepicker/js/bootstrap-datetimepicker.min.js" type="text/javascript"></script>

        <script src="../../../../assets/pages/scripts/components-date-time-pickers.min.js" type="text/javascript"></script>

        <script type="text/javascript">

    		$(".date-picker").datetimepicker({format: 'yyyy-mm-dd hh:ii'});

		</script>
	
	<!-- Configure a few settings and attach camera -->

    </body>



</html>