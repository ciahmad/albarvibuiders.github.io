<?php 

include("chksession.php");

include("Common.php");

include('header.php');
$sql="select * from qoutations where project_id='".mysqli_real_escape_string($con,$_GET['id'])."'";
$result=mysqli_query($con,$sql);



 ?>

        <!-- BEGIN CONTAINER -->

        <div class="page-container">

            <!-- BEGIN SIDEBAR -->

            <?php include('left_sidebar.php'); ?>

            <!-- END SIDEBAR -->

            <!-- BEGIN CONTENT -->

            <div class="page-content-wrapper">

                <!-- BEGIN CONTENT BODY -->

                <div class="page-content">

                    <!-- BEGIN PAGE HEAD-->

                    <div class="page-head">

                        <!-- BEGIN PAGE TITLE -->

                        <div class="page-title">

                            <h1>Project Management

                                <small>View Project</small>

                            </h1>
                            

                        </div>
                        <div class="btn-group btn-group-justified" style="width:inherit; float:right">
                        	<a class="btn btn-default" href="view_project.php?id=<?php echo $_GET['id'];?>" style="width:inherit;"> Details </a>
                        	<a class="btn btn-default" href="project_qoutations.php?id=<?php echo $_GET['id'];?>" style="width:inherit;"> Qoutations </a>
                            <a class="btn btn-default blue" href="project_resources.php?id=<?php echo $c['id']?>" style="width:inherit;"> Resources </a>
                            <a class="btn btn-default" href="javascript:;" style="width:inherit;"> Expenses </a>
                            <a class="btn btn-default" href="javascript:;" style="width:inherit;"> Right </a>
                      	</div>
                        
                        

                        <!-- END PAGE TITLE -->

                        <!-- BEGIN PAGE TOOLBAR -->

                        

                        <!-- END PAGE TOOLBAR -->

                    </div>

                    <!-- END PAGE HEAD-->

                    <!-- BEGIN PAGE BREADCRUMB -->

                    <ul class="page-breadcrumb breadcrumb">

                        <li>

                            <a href="../../../../admin/projects.php">Project</a>

                            <i class="fa fa-circle"></i>

                        </li>

                        <li>

                            <span class="active">View Project</span>

                        </li>

                    </ul>
                    

                    <!-- END PAGE BREADCRUMB -->

                    <!-- BEGIN PAGE BASE CONTENT -->

                    
					
                    
                    <div class="portlet box blue">
                                <div class="portlet-title">
                                    <div class="caption">
                                        <i class="fa fa-gift"></i>Human Resources </div>
                                    <div class="tools">
                                        <a class="collapse" href="javascript:;" data-original-title="" title=""> </a>
                                        <a class="config" data-toggle="modal" href="#portlet-config" data-original-title="" title=""> </a>
                                    </div>
                                </div>
                                <div class="portlet-body">
                                    <div class="tabbable-custom ">
                                        <ul class="nav nav-tabs ">
                                            <li class="active">
                                                <a data-toggle="tab" href="#add_qoutation" aria-expanded="false"> Add HR </a>
                                            </li>
                                        </ul>
                                        <div class="tab-content">
                                            
                                            <!--<div id="tab_5_2" class="tab-pane">
                                                <p> Howdy, I'm in Section 2. </p>
                                                <p> Ut wisi enim ad minim veniam, quis nostrud exerci tation ullamcorper suscipit lobortis nisl ut aliquip ex ea commodo consequat. Duis autem vel eum iriure dolor in hendrerit in vulputate velit esse molestie
                                                    consequat. Ut wisi enim ad minim veniam, quis nostrud exerci tation. </p>
                                                <p>
                                                    <a target="_blank" href="ui_tabs_accordions_navs.html#tab_5_2" class="btn green"> Activate this tab via URL </a>
                                                </p>
                                            </div>-->
                                            <?php
                                            $query="select projects.*, customers.company, customers.cperson_name  from projects LEFT JOIN customers ON projects.id_customer = customers.id where projects.id='".mysqli_real_escape_string($con,$_GET['id'])."'";
											$project=mysqli_query($con,$query);

											$p=mysqli_fetch_array($project);
                                            ?>
                                            <div id="add_qoutation" class="tab-pane active">
                         <form class="form-horizontal" method="post" role="form" action="add_qoutation2.php?project_id=<?php echo mysqli_real_escape_string($con,$_GET['id']); ?>" enctype="multipart/form-data">

                                        <div class="form-body">
										
											
                                        
										 
										<div class="panel panel-default form-panel">

  <div class="panel-heading"> Project's HR</div>
  <div class="panel-body">

    <div class="row">
      <div class="col-md-1">
        <h5 class="bold center">Delete</h5>
      </div>

      <div class="col-md-3">
        <h5 class="bold">Name</h5>
      </div>

      <div class="col-md-3">
        <h5 class="bold">Email</h5>
      </div>

      <div class="col-md-3">
        <h5 class="bold">Phone</h5>
      </div>
      
      <div class="col-md-2">
        <h5 class="bold">Designation</h5>
      </div>
      



    </div>

    <ul class="job-item-list no-style-list listis" id="job_item_list" style="padding-left:0; list-style:none;">

    </ul>

    <hr>
    
    <a class="btn btn-default addLaborToJob"><i class="fa fa-plus"></i></a>
     <div class="col-md-4 col-lg-4">
   <select name="select_item" class="select-2-basic tech_unselected" data-width="80%" >
   		<option value="">Select Employee</option>
   
    		</select>
</div>
  </div>
</div>

<hr />



                                        
                                        
                                        <div style="clear:both"></div>	
											
                                        <div class="form-actions right1">

                                            <button type="button" class="btn default" onclick="window.location='projects.php'">Cancel</button>

                                            <button type="submit" class="btn green">Save</button>

                                        </div>
                                        
                                        </div>

                                    </form>
                                            </div>
                                        </div>
                                    </div>
                                    
                                </div>
                            </div>
                            

                    <!-- END PAGE BASE CONTENT -->

                </div>

                <!-- END CONTENT BODY -->

            </div>

            <!-- END CONTENT -->

            <!-- BEGIN QUICK SIDEBAR -->

            

            

            <!-- END QUICK SIDEBAR -->

        </div>

        <!-- END CONTAINER -->

        <!-- BEGIN FOOTER -->

        <?php include('footer.php'); ?>

        

        <!-- END FOOTER -->

        <!-- BEGIN QUICK NAV -->

       
        
        <!-- END QUICK NAV -->

        <!--[if lt IE 9]>

<script src="../assets/global/plugins/respond.min.js"></script>

<script src="../assets/global/plugins/excanvas.min.js"></script> 

<script src="../assets/global/plugins/ie8.fix.min.js"></script> 

<![endif]-->

        <!-- BEGIN CORE PLUGINS -->

        <?php include('core_plugins.php'); ?>

        <script src="js/resources.js" type="text/javascript"></script>
  		<script src="js/bootstrap-chosen.js" type="text/javascript"></script>

    </body>



</html>