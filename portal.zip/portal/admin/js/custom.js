// JavaScript Document
//var surl=" http://localhost/kohat/admin/";

	Webcam.set({
			// live preview size
			width: 240,
			height: 240,
			
			// device capture size
			dest_width: 240,
			dest_height: 240,
			
			// final cropped size
			crop_width: 240,
			crop_height: 240,
			
			// format and quality
			image_format: 'png',
			jpeg_quality: 90
		});
		
		//Webcam.attach( '#my_camera' );
		function take_snapshot() {
			document.getElementById("photo-btn").style.display = "none";
			document.getElementById("camera-btn").style.display = "block";
				//$("#photo-btn").hide();
				//$("#camera-btn").show();
			// take snapshot and get image data
			Webcam.snap( function(data_uri) {
				// display results in page
				document.getElementById('my_camera').innerHTML = '<img src="'+data_uri+'"/>';
					document.getElementById('photo').value = data_uri;
			} );
		}
		function attach_webcam() {
			document.getElementById("camera-btn").style.display = "none";
			document.getElementById("photo-btn").style.display = "block";
			//$("#photo-btn").show();
			// take snapshot and get image data
			Webcam.attach( '#my_camera' );
		}
		
		function check_cnic(){
				$('#balck_list').css('display', 'none');
				var cnic=$("#check_nic").val();
				var type=$("#type").val();
				$.get('check_cnic.php',{cnic:cnic,type:type},function(data){
					console.log(data);
					var rs=JSON.parse(data);
					//alert(rs["Black_list"]);
					if(rs["Black_list"]==1){
					$('#balck_list').css('display', 'block');
					blink('#balck_list');
					$('#submit_btn').css('display', 'none');
					}
					if(rs["data"]["id"] > 0){
						$("#card_no").val(rs["data"]["card_no"]);
						$("#cnic_no").val(rs["data"]["cnic_no"]);
						$("#name").val(rs["data"]["name"]);
						$("#house_no").val(rs["data"]["house_no"]);
						$("#street").val(rs["data"]["street"]);
						$("#complete_add").val(rs["data"]["complete_add"]);
						$("#mob_no").val(rs["data"]["mob_no"]);
						$("#veh_reg_no").val(rs["data"]["veh_reg_no"]);
						$("#make").val(rs["data"]["make"]);
						
						$("#sponsor").val(rs["data"]["sponsor"]);
						$("#svas_obsn").val(rs["data"]["svas_obsn"]);
						$("#validity").val(rs["data"]["validity"]);
						$("#tehsil").val(rs["data"]["tehsil"]);
						$("#district").val(rs["data"]["district"]);
						$("#province").val(rs["data"]["province"]);
						//$("#gender").val(rs["data"]["gender"]);
						$("#proceed_to").val(rs["data"]["proceed_to"]);
						
						$("#photo").val(rs["data"]["photo"]);
						$("#my_camera img").attr("src", rs["data"]["photo"]);
						
						if(type=="visitor"){
							
							$("#children").val(rs["data"]["children"]);
							$("#purpose").val(rs["data"]["purpose"]);
							$("#hour").val(rs["data"]["hour"]);
							$("input[name=gender][value=" + rs["data"]["gender"] + "]").attr('checked', 'checked');
							
						}else if(type=="labour"){
							
							$("#contractor_name").val(rs["data"]["contractor_name"]);
							$("input[name=police_verification][value=" + rs["data"]["police_verification"] + "]").attr('checked', 'checked');
							$("input[name=verified_by][value=" + rs["data"]["verified_by"] + "]").attr('checked', 'checked');
							$("input[name=spec_permission][value=" + rs["data"]["spec_permission"] + "]").attr('checked', 'checked');
							
						}
						//load_image(rs["data"]["id"]);
						
					}else{
						//return false;
						$("#cnic_no").val(cnic);
						$("#card_no").focus();
					}
				});
			}
			
			function blink(selector){
				$(selector).fadeOut('slow', function(){
					$(this).fadeIn('slow', function(){
						blink(this);
					});
				});
			}
			
			
		function calculate_age(){
				var dob=$("#dob").val();
				if(dob==""){
					return false;
				}
				dob = new Date(dob);
				var today = new Date();
				var age = Math.floor((today-dob) / (365.25 * 24 * 60 * 60 * 1000));
				
				$('#age').val(age+" Years");
			}
			
			
			
		function load_districts(){
				
				var province=$("#province").val();
				$.get('load_districts.php',{province:province},function(data){
					console.log(data);
					$("#district").html(data);
					//var rs=JSON.parse(data);
					
				});
			}
			
			
		function load_tehsils(){
				
				var province=$("#province").val();
				var district=$("#district").val();
				$.get('load_tehsils.php',{province:province,district:district},function(data){
					console.log(data);
					$("#tehsil").html(data);
					
				});
			}
			
		function load_sub_categories(){
				
				var main_cat=$("#proceed_to").val();
				$.get('load_sub_categories.php',{main_cat:main_cat},function(data){
					console.log(data);
					$("#sub_proceed_to").html(data);
					
				});
			}